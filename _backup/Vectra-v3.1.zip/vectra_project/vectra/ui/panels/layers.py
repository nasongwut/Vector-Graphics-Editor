"""Layers tab: every object, top of the stack first, with visibility and lock toggles."""

import tkinter as tk

from vectra.config import SHIFT_MASK
from vectra.i18n import tr
from vectra.model import shapes as sh
from vectra.ui.theme import T
from vectra.ui.widgets import Tooltip

TYPE_ICON = {"rect": "▢", "ellipse": "◯", "line": "╱", "polygon": "⬠", "pen": "✎", "path": "✒", "text": "T"}


class LayersTab:
    def __init__(self, ed, parent):
        self.ed = ed
        tk.Label(parent, text=tr("sec_layers"), bg=T["panel"], fg=T["muted"],
                 font=ed.f(9, "bold")).pack(anchor="w", padx=18, pady=(14, 4))
        tk.Label(parent, text=tr("layers_hint"), bg=T["panel"], fg=T["muted"], font=ed.f(8),
                 wraplength=230, justify="left").pack(anchor="w", padx=18, pady=(0, 8))
        self.body = tk.Frame(parent, bg=T["panel"])
        self.body.pack(fill="both", expand=True, padx=10, pady=(0, 12))
        self._signature = None

    def _sig(self):
        ed = self.ed
        return tuple((s["id"], s["type"], s.get("name"), s.get("text"), sh.prop(s, "hidden"),
                      sh.prop(s, "locked"), s.get("gid"), s["id"] in ed.selected)
                     for s in ed.doc.shapes)

    def refresh(self, force=False):
        sig = self._sig()
        if sig == self._signature and not force:
            return
        self._signature = sig
        for w in self.body.winfo_children():
            w.destroy()
        ed = self.ed
        if not ed.doc.shapes:
            tk.Label(self.body, text=tr("layers_empty"), bg=T["panel"], fg=T["muted"],
                     font=ed.f(9)).pack(anchor="w", padx=8, pady=8)
            return
        for s in reversed(ed.doc.shapes):
            self._row(s)

    def _row(self, s):
        ed = self.ed
        selected = s["id"] in ed.selected
        hidden, locked = sh.prop(s, "hidden"), sh.prop(s, "locked")
        bg = T["accent"] if selected else T["panel"]
        fg = "#ffffff" if selected else (T["muted"] if hidden else T["text"])
        row = tk.Frame(self.body, bg=bg, cursor="hand2")
        row.pack(fill="x", pady=1)

        def mk(text, font, color=fg, **kw):
            lbl = tk.Label(row, text=text, bg=bg, fg=color, font=font, **kw)
            return lbl

        eye = mk("◌" if hidden else "◉", ed.f(10), color=fg, width=2)
        eye.pack(side="left", padx=(4, 0))
        lock = mk("🔒" if locked else "·", ed.f(9), color=fg, width=2)
        lock.pack(side="left")
        indent = "    " if s.get("gid") is not None else ""
        mk(indent + TYPE_ICON.get(s["type"], "?"), ed.f(10)).pack(side="left", padx=(4, 4))
        swatch = tk.Canvas(row, width=12, height=12, bg=bg, highlightthickness=0)
        swatch.create_rectangle(1, 1, 11, 11, fill=s.get("fill") or s.get("stroke") or bg,
                                outline=T["border"])
        swatch.pack(side="left", padx=(0, 6))
        name = mk(sh.display_name(s), ed.f(9), anchor="w")
        name.pack(side="left", fill="x", expand=True, pady=4)
        if s.get("gid") is not None:
            mk(f"G{s['gid']}", (ed.mono, 8), color="#ffffff" if selected else T["accent2"]).pack(side="right",
                                                                                                padx=6)

        sid = s["id"]
        eye.bind("<Button-1>", lambda e: (ed.toggle_hidden(sid), "break")[1])
        lock.bind("<Button-1>", lambda e: (ed.toggle_locked(sid), "break")[1])
        Tooltip(eye, tr("tip_eye"), side="below", font=ed.f(9))
        Tooltip(lock, tr("tip_lock"), side="below", font=ed.f(9))
        for w in (row, name, swatch) + tuple(c for c in row.winfo_children() if c not in (eye, lock)):
            w.bind("<Button-1>", lambda e: ed.select_from_layers(sid, bool(e.state & SHIFT_MASK)))
            w.bind("<Double-Button-1>", lambda e: ed.rename_shape(sid))
