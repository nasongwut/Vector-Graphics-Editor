"""Edit, arrange and object commands."""

import copy
from tkinter import simpledialog

from vectra.config import ARTBOARD
from vectra.i18n import tr
from vectra.model import geometry as geo
from vectra.model import shapes as sh


class CommandsMixin:
    # ── creating shapes ─────────────────────────────────────────────────────
    def new_shape(self, typ, pts):
        return sh.make_shape(typ, pts, self.current_style())

    def add_shape(self, s):
        self.push_undo()
        s = self.doc.add(s)
        self.selected = {s["id"]}
        return s

    def finish_polygon(self):
        pts = self.poly_pts
        self.poly_pts = []
        if len(pts) >= 6:
            self.add_shape(self.new_shape("polygon", pts))
            self.on_selection_changed()
        elif len(pts) == 4:
            self.add_shape(self.new_shape("line", pts))
            self.on_selection_changed()
        self.render()

    def add_text(self, x, y):
        txt = simpledialog.askstring(tr("text_title"), tr("text_prompt"), parent=self.root)
        if txt:
            s = self.new_shape("text", [x, y])
            s["text"] = txt
            self.add_shape(s)
            self.on_selection_changed()
            self.render()

    # ── selection-wide edits ────────────────────────────────────────────────
    def _changed(self, flash=None):
        self.on_selection_changed()
        self.render()
        if flash:
            self.flash(flash)

    def delete_sel(self):
        if not self.selected:
            return
        self.push_undo()
        self.doc.remove(self.selected)
        self.selected.clear()
        self._changed()

    def select_all(self):
        self.set_tool("select")
        self.selected = {s["id"] for s in self.doc.editable()}
        self._changed()

    def _insert_copies(self, items, offset):
        self.push_undo()
        self.selected = self.doc.insert_copies(items, offset)
        self._changed()

    def duplicate(self):
        if self.selected:
            self._insert_copies(self.selected_shapes(), 16)
            self.flash(tr("flash_duplicated"))

    def copy_sel(self):
        if self.selected:
            self.clipboard = copy.deepcopy(self.selected_shapes())
            self.flash(tr("flash_copied", n=len(self.clipboard)))

    def paste(self):
        if self.clipboard:
            self._insert_copies(self.clipboard, 20)
            self.clipboard = copy.deepcopy(self.selected_shapes())  # cascade next paste

    def nudge(self, dx, dy):
        if not self.selected:
            return
        self.push_undo("nudge")
        for s in self.selected_shapes():
            sh.translate(s, dx, dy)
        self.render()

    # ── stacking order ──────────────────────────────────────────────────────
    def _reorder(self, op):
        if self.selected:
            self.push_undo()
            op(self.selected)
            self.render()

    def bring_front(self):
        self._reorder(self.doc.bring_front)

    def send_back(self):
        self._reorder(self.doc.send_back)

    def bring_forward(self):
        self._reorder(self.doc.bring_forward)

    def send_backward(self):
        self._reorder(self.doc.send_backward)

    # ── view toggles ────────────────────────────────────────────────────────
    def toggle_grid(self):
        self.show_grid = not self.show_grid
        self.refresh_panel()
        self.render()

    def toggle_snap(self):
        self.snap = not self.snap
        self.refresh_panel()
        self.flash(tr("flash_snap_on") if self.snap else tr("flash_snap_off"))

    # ── groups ──────────────────────────────────────────────────────────────
    def group_sel(self):
        if len(self.selected) < 2:
            return
        self.push_undo()
        self.doc.group(self.selected)
        self._changed(tr("flash_grouped", n=len(self.selected)))

    def ungroup_sel(self):
        if not self.selected:
            return
        if any(s.get("gid") is not None for s in self.selected_shapes()):
            self.push_undo()
            self.doc.ungroup(self.selected)
            self._changed(tr("flash_ungrouped"))

    # ── lock / hide ─────────────────────────────────────────────────────────
    def lock_sel(self):
        if not self.selected:
            return
        n = len(self.selected)
        self.push_undo()
        for s in self.selected_shapes():
            s["locked"] = True
        self.selected.clear()
        self._changed(tr("flash_locked", n=n))

    def unlock_all(self):
        locked = [s for s in self.doc.shapes if sh.prop(s, "locked")]
        if not locked:
            return
        self.push_undo()
        for s in locked:
            s.pop("locked", None)
        self.selected = {s["id"] for s in locked if not sh.prop(s, "hidden")}
        self._changed(tr("flash_unlocked"))

    def hide_sel(self):
        if not self.selected:
            return
        n = len(self.selected)
        self.push_undo()
        for s in self.selected_shapes():
            s["hidden"] = True
        self.selected.clear()
        self._changed(tr("flash_hidden", n=n))

    def show_all(self):
        hidden = [s for s in self.doc.shapes if sh.prop(s, "hidden")]
        if not hidden:
            return
        self.push_undo()
        for s in hidden:
            s.pop("hidden", None)
        self.selected = {s["id"] for s in hidden if not sh.prop(s, "locked")}
        self._changed(tr("flash_shown"))

    def toggle_hidden(self, sid):
        s = self.doc.by_id(sid)
        if not s:
            return
        self.push_undo()
        if sh.prop(s, "hidden"):
            s.pop("hidden", None)
        else:
            s["hidden"] = True
            self.selected.discard(sid)
        self._changed()

    def toggle_locked(self, sid):
        s = self.doc.by_id(sid)
        if not s:
            return
        self.push_undo()
        if sh.prop(s, "locked"):
            s.pop("locked", None)
        else:
            s["locked"] = True
            self.selected.discard(sid)
        self._changed()

    # ── layers panel actions ────────────────────────────────────────────────
    def select_from_layers(self, sid, add=False):
        s = self.doc.by_id(sid)
        if not s or sh.prop(s, "hidden") or sh.prop(s, "locked"):
            return
        if self.tool not in ("select", "direct"):
            self.set_tool("select")
        if add:
            self.selected ^= {sid}
        else:
            self.selected = {sid}
        self._changed()

    def rename_shape(self, sid):
        s = self.doc.by_id(sid)
        if not s:
            return
        name = simpledialog.askstring(tr("rename_title"), tr("rename_prompt"),
                                      initialvalue=s.get("name") or sh.display_name(s), parent=self.root)
        if name is None:
            return
        self.push_undo()
        name = name.strip()
        if name:
            s["name"] = name
        else:
            s.pop("name", None)
        self._changed()

    # ── align / distribute ──────────────────────────────────────────────────
    def _unit_bbox(self, unit):
        return geo.union_bbox([self.shape_bbox(s) for s in unit])

    def align(self, how):
        units = self.doc.units(self.selected)
        if not units:
            return
        target = ARTBOARD if len(units) == 1 else self.selection_bbox()
        tx0, ty0, tx1, ty1 = target
        moves = []
        for unit in units:
            b = self._unit_bbox(unit)
            dx = dy = 0.0
            if how == "left":
                dx = tx0 - b[0]
            elif how == "right":
                dx = tx1 - b[2]
            elif how == "hcenter":
                dx = (tx0 + tx1) / 2 - (b[0] + b[2]) / 2
            elif how == "top":
                dy = ty0 - b[1]
            elif how == "bottom":
                dy = ty1 - b[3]
            elif how == "vcenter":
                dy = (ty0 + ty1) / 2 - (b[1] + b[3]) / 2
            if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                moves.append((unit, dx, dy))
        if not moves:
            return
        self.push_undo()
        for unit, dx, dy in moves:
            for s in unit:
                sh.translate(s, dx, dy)
        self.render()

    def distribute(self, axis):
        units = self.doc.units(self.selected)
        if len(units) < 3:
            return
        i0 = 0 if axis == "h" else 1
        items = []
        for unit in units:
            b = self._unit_bbox(unit)
            items.append(((b[i0] + b[i0 + 2]) / 2, unit))
        items.sort(key=lambda t: t[0])
        first, last = items[0][0], items[-1][0]
        step = (last - first) / (len(items) - 1)
        self.push_undo()
        for k, (c, unit) in enumerate(items):
            delta = first + k * step - c
            for s in unit:
                sh.translate(s, delta if axis == "h" else 0, delta if axis == "v" else 0)
        self.render()

    # ── transforms ──────────────────────────────────────────────────────────
    def flip(self, axis):
        bb = self.selection_bbox()
        if not bb:
            return
        cx, cy = geo.bbox_center(bb)
        boxes = {s["id"]: self.shape_bbox(s) for s in self.selected_shapes()}
        self.push_undo()
        for s in self.selected_shapes():
            sh.replace_in_place(s, sh.flipped(s, axis, cx if axis == "h" else cy, boxes[s["id"]]))
        self._changed()

    def rotate_sel(self, deg):
        bb = self.selection_bbox()
        if not bb or not deg:
            return
        cx, cy = geo.bbox_center(bb)
        self.push_undo()
        for s in self.selected_shapes():
            sh.replace_in_place(s, sh.rotated(s, deg, cx, cy))
        self._changed()

    def apply_transform(self, field, text):
        """Called from the X / Y / W / H / angle fields."""
        try:
            value = float(text.replace(",", "."))
        except ValueError:
            self.panel.show_geometry()
            return
        bb = self.selection_bbox()
        if not bb:
            return
        x0, y0, x1, y1 = bb
        if field in ("x", "y"):
            dx = value - x0 if field == "x" else 0
            dy = value - y0 if field == "y" else 0
            if dx or dy:
                self.push_undo()
                for s in self.selected_shapes():
                    sh.translate(s, dx, dy)
        elif field in ("w", "h"):
            if value <= 0:
                self.panel.show_geometry()
                return
            nb = (x0, y0, x0 + value, y1) if field == "w" else (x0, y0, x1, y0 + value)
            if (field == "w" and x1 - x0 == 0) or (field == "h" and y1 - y0 == 0):
                self.panel.show_geometry()
                return
            self.push_undo()
            for s in self.selected_shapes():
                sh.replace_in_place(s, sh.scaled(s, bb, nb))
        elif field == "rot":
            sel = self.selected_shapes()
            current = sh.prop(sel[0], "rot") if len(sel) == 1 else 0
            self.rotate_sel(geo.normalize_angle(value - current))
            return
        self._changed()
