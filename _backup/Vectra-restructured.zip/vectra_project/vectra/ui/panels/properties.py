"""Properties tab: selection info, transform fields, appearance, swatches."""

import tkinter as tk

from vectra.config import IS_MAC
from vectra.i18n import tr
from vectra.model import shapes as sh
from vectra.ui.panels.common import section
from vectra.ui.theme import PALETTE, T
from vectra.ui.widgets import DarkEntry, FlatButton, Swatch, Tooltip


class PropertiesTab:
    def __init__(self, ed, parent):
        self.ed = ed
        p = parent

        # ── selection info ─────────────────────────────────────────────────
        s = section(p, ed, tr("sec_selection"), first=True)
        self.info_title = tk.Label(s, text="", bg=T["panel"], fg=T["text"],
                                   font=ed.f(11, "bold"), anchor="w")
        self.info_title.pack(fill="x")
        self.info_sub = tk.Label(s, text="", bg=T["panel"], fg=T["muted"], font=ed.f(9),
                                 anchor="w", justify="left")
        self.info_sub.pack(fill="x", pady=(2, 0))

        # ── transform ──────────────────────────────────────────────────────
        s = section(p, ed, tr("sec_transform"))
        grid = tk.Frame(s, bg=T["panel"])
        grid.pack(fill="x")
        self.entries = {}
        for i, (key, label) in enumerate((("x", "X"), ("y", "Y"), ("w", "W"), ("h", "H"),
                                          ("rot", tr("angle")))):
            r, col = divmod(i, 2)
            tk.Label(grid, text=label, bg=T["panel"], fg=T["muted"],
                     font=(ed.mono, 9)).grid(row=r, column=col * 2, sticky="w", padx=(0 if col == 0 else 10, 6),
                                             pady=3)
            e = DarkEntry(grid, font=(ed.mono, 10), width=7,
                          on_commit=lambda v, k=key: ed.apply_transform(k, v))
            e.grid(row=r, column=col * 2 + 1, sticky="ew", pady=3, ipady=3)
            Tooltip(e, tr("tip_transform"), side="below", font=ed.f(9))
            self.entries[key] = e
        grid.columnconfigure(1, weight=1)
        grid.columnconfigure(3, weight=1)

        # ── appearance ─────────────────────────────────────────────────────
        s = section(p, ed, tr("sec_appearance"))
        self.fill_sw, self.fill_hex = self._color_row(s, tr("fill"), "fill")
        self.stroke_sw, self.stroke_hex = self._color_row(s, tr("stroke"), "stroke")

        row = tk.Frame(s, bg=T["panel"])
        row.pack(fill="x", pady=(6, 0))
        FlatButton(row, tr("swap"), ed.swap_colors, font=ed.f(9), bg=T["panel2"], padx=8, pady=4,
                   tooltip=tr("tip_swap"), tip_font=ed.f(9)).pack(side="left", fill="x", expand=True, padx=(0, 2))
        FlatButton(row, tr("default_colors"), ed.default_colors, font=ed.f(9), bg=T["panel2"], padx=8, pady=4,
                   tooltip=tr("tip_default_colors"), tip_font=ed.f(9)).pack(side="left", fill="x",
                                                                           expand=True, padx=2)
        self.dash_btn = FlatButton(row, "┅ " + tr("dashed"), ed.toggle_dash, font=ed.f(9), bg=T["panel2"],
                                   padx=8, pady=4, tooltip=tr("tip_dashed"), tip_font=ed.f(9))
        self.dash_btn.pack(side="left", fill="x", expand=True, padx=(2, 0))

        self.width_sc, self.width_val = self._slider(s, tr("stroke_width"), 0, 40, ed.on_width_change)
        self.radius_sc, self.radius_val = self._slider(s, tr("corner_radius"), 0, 200, ed.on_radius_change)
        self.size_sc, self.size_val = self._slider(s, tr("font_size"), 8, 200, ed.on_size_change)

        # ── swatches ───────────────────────────────────────────────────────
        tk.Label(s, text=tr("palette_hint"), bg=T["panel"], fg=T["muted"],
                 font=ed.f(8)).pack(anchor="w", pady=(14, 6))
        pal = tk.Frame(s, bg=T["panel"])
        pal.pack(anchor="w", pady=(0, 16))
        rbtn = "<Button-2>" if IS_MAC else "<Button-3>"
        for i, col in enumerate(PALETTE):
            cv = tk.Canvas(pal, width=26, height=26, bg=T["panel"], highlightthickness=0, cursor="hand2")
            cv.grid(row=i // 8, column=i % 8, padx=2, pady=2)
            cv.create_rectangle(2, 2, 24, 24, fill=col, outline=T["border"])
            cv.bind("<Button-1>", lambda e, c=col: ed.set_color("fill", c))
            cv.bind(rbtn, lambda e, c=col: ed.set_color("stroke", c))

    # ── builders ────────────────────────────────────────────────────────────
    def _color_row(self, parent, label, which):
        ed = self.ed
        row = tk.Frame(parent, bg=T["panel"])
        row.pack(fill="x", pady=4)
        sw = Swatch(row, 30, command=lambda: ed.pick_color(which))
        sw.pack(side="left")
        col = tk.Frame(row, bg=T["panel"])
        col.pack(side="left", padx=10)
        tk.Label(col, text=label, bg=T["panel"], fg=T["text"], font=ed.f(10)).pack(anchor="w")
        hx = tk.Label(col, text="", bg=T["panel"], fg=T["muted"], font=(ed.mono, 9))
        hx.pack(anchor="w")
        FlatButton(row, tr("none"), lambda: ed.set_color(which, None), font=ed.f(9),
                   bg=T["panel2"], padx=9, pady=3).pack(side="right")
        return sw, hx

    def _slider(self, parent, label, frm, to, cmd):
        ed = self.ed
        row = tk.Frame(parent, bg=T["panel"])
        row.pack(fill="x", pady=(10, 0))
        tk.Label(row, text=label, bg=T["panel"], fg=T["text"], font=ed.f(10)).pack(side="left")
        val = tk.Label(row, text="", bg=T["panel"], fg=T["accent2"], font=(ed.mono, 10, "bold"))
        val.pack(side="right")
        sc = tk.Scale(parent, from_=frm, to=to, orient="horizontal", showvalue=False,
                      bg=T["accent"], fg=T["text"], troughcolor=T["panel2"],
                      activebackground=T["accent2"], highlightthickness=0, bd=0,
                      sliderrelief="flat", sliderlength=16, width=8, command=cmd)
        sc.pack(fill="x", pady=(4, 0))
        return sc, val

    # ── refresh ─────────────────────────────────────────────────────────────
    def refresh(self):
        ed = self.ed
        self.fill_sw.set(ed.fill)
        self.stroke_sw.set(ed.stroke)
        self.fill_hex.config(text=(ed.fill or tr("none")).upper())
        self.stroke_hex.config(text=(ed.stroke or tr("none")).upper())
        self.width_sc.set(ed.width)
        self.width_val.config(text=f"{ed.width}px")
        self.radius_sc.set(ed.radius)
        self.radius_val.config(text=f"{ed.radius:g}px")
        self.size_sc.set(ed.font_size)
        self.size_val.config(text=f"{ed.font_size}px")
        self.dash_btn.set_active(ed.dash)

        sel = ed.selected_shapes()
        if not sel:
            self.info_title.config(text=tr("no_selection"))
            self.info_sub.config(text=tr("no_selection_hint"))
        else:
            gids = {s.get("gid") for s in sel}
            if len(sel) == 1:
                title = sh.display_name(sel[0])
            elif len(gids) == 1 and None not in gids:
                title = tr("group_of", n=len(sel))
            else:
                title = tr("n_selected", n=len(sel))
            self.info_title.config(text=title)
            self.info_sub.config(text="")
        self.show_geometry()

    def show_geometry(self):
        ed = self.ed
        bb = ed.selection_bbox()
        state = "normal" if bb else "disabled"
        for e in self.entries.values():
            e.config(state=state)
        if not bb:
            for e in self.entries.values():
                e.show("")
            return
        self.entries["x"].show(f"{bb[0]:.0f}")
        self.entries["y"].show(f"{bb[1]:.0f}")
        self.entries["w"].show(f"{bb[2] - bb[0]:.0f}")
        self.entries["h"].show(f"{bb[3] - bb[1]:.0f}")
        sel = ed.selected_shapes()
        self.entries["rot"].show(f"{sh.prop(sel[0], 'rot'):g}" if len(sel) == 1 else "0")

    def show_width(self, v):
        self.width_val.config(text=f"{v}px")

    def show_size(self, v):
        self.size_val.config(text=f"{v}px")

    def show_radius(self, v):
        self.radius_val.config(text=f"{v:g}px")
