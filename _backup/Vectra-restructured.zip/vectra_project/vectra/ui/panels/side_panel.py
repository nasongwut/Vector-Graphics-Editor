"""Right-hand panel with tabs: Properties · Arrange · Layers."""

import tkinter as tk

from vectra.i18n import tr
from vectra.ui.panels.arrange import ArrangeTab
from vectra.ui.panels.layers import LayersTab
from vectra.ui.panels.properties import PropertiesTab
from vectra.ui.theme import T
from vectra.ui.widgets import FlatButton, ScrollFrame

TABS = (("props", "tab_props"), ("arrange", "tab_arrange"), ("layers", "tab_layers"))


class SidePanel:
    def __init__(self, ed, parent, current="props"):
        self.ed = ed
        bar = tk.Frame(parent, bg=T["panel"])
        bar.pack(side="top", fill="x", padx=10, pady=(10, 0))
        tk.Frame(parent, bg=T["border"], height=1).pack(side="top", fill="x", pady=(8, 0))

        self.tab_buttons, self.frames = {}, {}
        for key, label in TABS:
            b = FlatButton(bar, tr(label), lambda k=key: self.show(k), font=ed.f(9, "bold"),
                           bg=T["panel"], padx=6, pady=5)
            b.pack(side="left", fill="x", expand=True, padx=1)
            self.tab_buttons[key] = b
            self.frames[key] = ScrollFrame(parent, bg=T["panel"])

        self.props = PropertiesTab(ed, self.frames["props"].inner)
        self.arrange = ArrangeTab(ed, self.frames["arrange"].inner)
        self.layers = LayersTab(ed, self.frames["layers"].inner)
        self.current = None
        self.show(current)

    def show(self, key):
        if key == self.current:
            return
        if self.current:
            self.frames[self.current].pack_forget()
        self.current = key
        self.frames[key].pack(side="top", fill="both", expand=True)
        for k, b in self.tab_buttons.items():
            b.set_active(k == key)
        if key == "layers":
            self.layers.refresh(force=True)

    def refresh(self):
        self.props.refresh()
        self.arrange.refresh()
        self.layers.refresh()

    def show_geometry(self):
        self.props.show_geometry()
