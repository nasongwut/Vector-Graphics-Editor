"""Helpers shared by the side-panel tabs."""

import tkinter as tk

from vectra.ui.theme import T


def section(parent, ed, title, first=False):
    """A titled block; returns the body frame to fill."""
    if not first:
        tk.Frame(parent, bg=T["border"], height=1).pack(fill="x", pady=(14, 0))
    tk.Label(parent, text=title, bg=T["panel"], fg=T["muted"],
             font=ed.f(9, "bold")).pack(anchor="w", padx=18, pady=(14, 8))
    body = tk.Frame(parent, bg=T["panel"])
    body.pack(fill="x", padx=18)
    return body


def button_grid(parent, buttons, columns=2):
    """Lay out FlatButtons in an even grid."""
    for i, b in enumerate(buttons):
        b.grid(row=i // columns, column=i % columns, sticky="ew", padx=2, pady=2)
    for col in range(columns):
        parent.columnconfigure(col, weight=1)
