"""The main window / controller.

``VectorEditor`` owns the state and wires the pieces together. Behaviour is split
into mixins by concern so each file stays readable:

    interaction.py  mouse, keyboard-driven tool behaviour, panning
    commands.py     edit / arrange / object commands
    style.py        fill, stroke, width ... and the properties panel sync
    files.py        new / open / save / export
"""

import os
import tkinter as tk

from vectra import i18n, settings
from vectra.config import (ARTBOARD, DEFAULT_FILL, DEFAULT_FONT_SIZE, DEFAULT_STAR_POINTS,
                           DEFAULT_STROKE, DEFAULT_WIDTH, GRID, APP_NAME)
from vectra.i18n import tr
from vectra.model import geometry as geo
from vectra.model import shapes as sh
from vectra.model.document import Document
from vectra.model.history import History
from vectra.ui.commands import CommandsMixin
from vectra.ui.files import FilesMixin
from vectra.ui.interaction import InteractionMixin
from vectra.ui.layout import build_context_menu, build_statusbar, build_toolbar, build_topbar
from vectra.ui.panels.side_panel import SidePanel
from vectra.ui.renderer import ROTATE, ROTATE_HANDLE_GAP, Renderer
from vectra.ui.shortcuts import bind_shortcuts
from vectra.ui.style import StyleMixin
from vectra.ui.theme import T, pick_font, pick_mono_font
from vectra.ui.tools import cursor_for, hint_key
from vectra.ui.viewport import Viewport

HANDLE_HIT = 7      # px


class VectorEditor(InteractionMixin, CommandsMixin, StyleMixin, FilesMixin):
    def __init__(self, root):
        self.root = root
        root.geometry("1360x860")
        root.minsize(1040, 660)
        root.configure(bg=T["bg"])

        self.ui_font = pick_font(root)
        self.mono = pick_mono_font(root)

        # document state
        self.doc = Document()
        self.history = History()
        self.selected = set()
        self.file_path = None
        self.dirty = False
        self.clipboard = []

        # style state (applies to new shapes & the selection)
        self.fill = DEFAULT_FILL
        self.stroke = DEFAULT_STROKE
        self.width = DEFAULT_WIDTH
        self.font_size = DEFAULT_FONT_SIZE
        self.radius = 0
        self.dash = False
        self.star_points = DEFAULT_STAR_POINTS

        # view / interaction state
        self.tool = "select"
        self.view = Viewport()
        self.show_grid = True
        self.snap = False
        self.drag = None
        self.temp = None
        self.poly_pts = []
        self.cursor_w = (0, 0)
        self.hover_id = None
        self.space = False
        self.tool_buttons = {}
        self._flash_job = None
        self._geo_job = None
        self.panel = None

        self.build_ui()
        bind_shortcuts(self)
        self.set_tool("select")
        self.update_title()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(60, self.zoom_fit)

    # ── UI construction (re-run when the language changes) ─────────────────
    def build_ui(self):
        r = self.root
        tab = self.panel.current if self.panel else "props"
        for w in r.winfo_children():
            w.destroy()
        self._flash_job = None

        build_topbar(self, r)
        build_statusbar(self, r)

        body = tk.Frame(r, bg=T["bg"])
        body.pack(side="top", fill="both", expand=True)
        self.tool_buttons = build_toolbar(self, body)

        right = tk.Frame(body, bg=T["panel"], width=290)
        right.pack(side="right", fill="y")
        right.pack_propagate(False)
        tk.Frame(body, bg=T["border"], width=1).pack(side="right", fill="y")
        self.panel = SidePanel(self, right, current=tab)

        self.canvas = tk.Canvas(body, bg=T["canvas"], highlightthickness=0, bd=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.renderer = Renderer(self)
        self.bind_canvas()
        self.menu = build_context_menu(self, r)

    def set_language(self, code):
        if code == i18n.get_language():
            return
        i18n.set_language(code)
        settings.set("language", code)
        self.build_ui()
        self.set_tool(self.tool)
        self.refresh_panel()
        self.update_title()
        self.root.after(30, self.render)
        self.flash(tr("flash_lang"))

    # ── helpers ─────────────────────────────────────────────────────────────
    def f(self, size=10, weight="normal"):
        return (self.ui_font, size, weight)

    def to_world(self, sx, sy):
        return self.view.to_world(sx, sy)

    def to_screen(self, pts):
        return self.view.to_screen(pts)

    def snapv(self, v):
        return round(v / GRID) * GRID if self.snap else v

    def selected_shapes(self):
        return self.doc.of_ids(self.selected)

    def current_style(self):
        return {"fill": self.fill, "stroke": self.stroke, "width": self.width,
                "font_size": self.font_size, "radius": self.radius, "dash": self.dash}

    def shape_bbox(self, s):
        if s["type"] == "text" and not sh.prop(s, "hidden"):
            b = self.canvas.bbox(f"s{s['id']}")
            if b:
                x0, y0 = self.to_world(b[0], b[1])
                x1, y1 = self.to_world(b[2], b[3])
                return (x0, y0, x1, y1)
        return sh.geometry_bbox(s)

    def selection_bbox(self):
        return geo.union_bbox([self.shape_bbox(s) for s in self.selected_shapes()])

    @staticmethod
    def handle_screen_points(x0, y0, x1, y1):
        return geo.handle_points(x0, y0, x1, y1)

    @staticmethod
    def rotate_handle_screen(x0, y0, x1, y1):
        return (x0 + x1) / 2, y0 - ROTATE_HANDLE_GAP

    def handle_at(self, sx, sy):
        """Index 0..7 of a resize handle, ROTATE for the rotation knob, or None."""
        bb = self.selection_bbox()
        if not bb:
            return None
        sbb = self.to_screen(list(bb))
        rx, ry = self.rotate_handle_screen(sbb[0] - 1, sbb[1] - 1, sbb[2] + 1, sbb[3] + 1)
        if abs(sx - rx) <= HANDLE_HIT and abs(sy - ry) <= HANDLE_HIT:
            return ROTATE
        for i, (hx, hy) in enumerate(self.handle_screen_points(*sbb)):
            if abs(sx - hx) <= HANDLE_HIT and abs(sy - hy) <= HANDLE_HIT:
                return i
        return None

    def hit(self, sx, sy):
        """Id of the top-most visible, unlocked shape under the screen point."""
        items = self.canvas.find_overlapping(sx - 3, sy - 3, sx + 3, sy + 3)
        for it in reversed(items):
            for tag in self.canvas.gettags(it):
                if tag.startswith("s") and tag[1:].isdigit():
                    s = self.doc.by_id(int(tag[1:]))
                    if s and not sh.prop(s, "locked"):
                        return s["id"]
        return None

    # ── history ─────────────────────────────────────────────────────────────
    def push_undo(self, key=None):
        if self.history.record(self.doc.snapshot, key):
            self.set_dirty(True)

    def _restore(self, snap):
        self.doc.restore(snap)
        self.selected &= self.doc.ids()
        self.set_dirty(True)
        self.on_selection_changed()
        self.render()

    def undo(self):
        snap = self.history.undo(self.doc.snapshot)
        if snap is not None:
            self._restore(snap)
            self.flash(tr("flash_undo"))

    def redo(self):
        snap = self.history.redo(self.doc.snapshot)
        if snap is not None:
            self._restore(snap)
            self.flash(tr("flash_redo"))

    def set_dirty(self, d):
        if self.dirty != d:
            self.dirty = d
            self.update_title()

    def update_title(self):
        name = os.path.basename(self.file_path) if self.file_path else tr("untitled")
        self.root.title(f"{'● ' if self.dirty else ''}{name} — {APP_NAME}")

    # ── rendering / status ──────────────────────────────────────────────────
    def render(self):
        self.renderer.render()
        self.update_status()
        if self.panel.current == "layers":
            self.panel.layers.refresh()
        if self._geo_job is None:
            self._geo_job = self.root.after_idle(self._refresh_geo)

    def status_text(self):
        x, y = self.cursor_w
        return f"X {x:7.1f}   Y {y:7.1f}    │   {tr('status_objects', n=len(self.doc.shapes))}"

    def update_status(self):
        if not self._flash_job:
            self.status_l.config(text=tr(hint_key(self.tool)), fg=T["muted"])
        self.status_r.config(text=self.status_text())
        self.zoom_lbl.config(text=f"{self.view.zoom * 100:.0f}%")

    def flash(self, msg):
        self.status_l.config(text=f"✓  {msg}", fg=T["accent2"])
        if self._flash_job:
            self.root.after_cancel(self._flash_job)

        def back():
            self._flash_job = None
            self.status_l.config(fg=T["muted"], text=tr(hint_key(self.tool)))
        self._flash_job = self.root.after(1600, back)

    # ── zoom ────────────────────────────────────────────────────────────────
    def zoom_at(self, factor, sx, sy):
        self.view.zoom_at(factor, sx, sy)
        self.render()

    def zoom_center(self, factor):
        c = self.canvas
        self.zoom_at(factor, c.winfo_width() / 2, c.winfo_height() / 2)

    def set_zoom(self, z):
        self.zoom_center(z / self.view.zoom)

    def zoom_fit(self):
        c = self.canvas
        if self.view.fit(ARTBOARD, c.winfo_width(), c.winfo_height()):
            self.render()

    def restore_cursor(self):
        self.canvas.config(cursor="fleur" if self.space else cursor_for(self.tool))

