"""Draws the document and the interaction overlay on the Tk canvas.

The renderer reads editor state but never changes it.
"""

from vectra.config import ARTBOARD, GRID, IS_MAC
from vectra.i18n import tr
from vectra.model import shapes as sh
from vectra.ui.theme import T

ROTATE_HANDLE_GAP = 24   # px above the selection box
ROTATE = "rotate"        # handle id of the rotation knob


def dash_pattern(width, zoom):
    w = max(1.0, width) * zoom
    return (max(1, min(255, int(round(w * 3)))), max(1, min(255, int(round(w * 2)))))


class Renderer:
    def __init__(self, editor):
        self.ed = editor

    @property
    def c(self):
        return self.ed.canvas

    # ── full frame ──────────────────────────────────────────────────────────
    def render(self):
        ed, c = self.ed, self.c
        c.delete("all")
        W, H = max(1, c.winfo_width()), max(1, c.winfo_height())
        step = ed.view.grid_step(GRID)
        if ed.show_grid:
            self._draw_background_grid(W, H, step)
        self._draw_artboard(W, H, step)
        for s in ed.doc.shapes:
            self.draw_shape(s)
        if ed.temp:
            self.draw_shape(ed.temp, temp=True)
        self._draw_polygon_preview()
        if ed.tool == "direct":
            self._draw_direct_overlay()
        else:
            self._draw_selection_overlay()

    def _draw_background_grid(self, W, H, step):
        c, v = self.c, self.ed.view
        x = v.ox % step
        while x < W:
            c.create_line(x, 0, x, H, fill=T["grid"])
            x += step
        y = v.oy % step
        while y < H:
            c.create_line(0, y, W, y, fill=T["grid"])
            y += step

    def _draw_artboard(self, W, H, step):
        c, ed = self.c, self.ed
        ax0, ay0, ax1, ay1 = ed.view.to_screen(list(ARTBOARD))
        c.create_rectangle(ax0 + 5, ay0 + 8, ax1 + 5, ay1 + 8, fill=T["shadow"], outline="")
        c.create_rectangle(ax0, ay0, ax1, ay1, fill=T["board"], outline="")
        if ed.show_grid:
            x = ax0
            while x <= ax1 + 0.5:
                if 0 <= x <= W:
                    c.create_line(x, max(ay0, 0), x, min(ay1, H), fill=T["board_grid"])
                x += step
            y = ay0
            while y <= ay1 + 0.5:
                if 0 <= y <= H:
                    c.create_line(max(ax0, 0), y, min(ax1, W), y, fill=T["board_grid"])
                y += step
        c.create_text(ax0, ay0 - 10, anchor="sw", fill=T["muted"], font=ed.f(9),
                      text=tr("artboard", w=ARTBOARD[2], h=ARTBOARD[3]))

    # ── shapes ──────────────────────────────────────────────────────────────
    def draw_shape(self, s, temp=False):
        if sh.prop(s, "hidden") and not temp:
            return
        c, ed = self.c, self.ed
        z = ed.view.zoom
        to_screen = ed.view.to_screen
        pts = to_screen(s["pts"])
        tags = ("temp",) if temp else ("shape", f"s{s['id']}")
        typ = s["type"]
        fill = s.get("fill") or ""
        stroke = s.get("stroke") or ""
        sw = s.get("width", 0)
        outline = stroke if (stroke and sw > 0) else ""
        w = max(1.0, sw * z) if outline else 0
        dash = dash_pattern(sw, z) if sh.prop(s, "dash") else None
        extra = {"dash": dash} if dash and outline else {}

        if typ in ("rect", "ellipse") and sh.renders_as_polygon(s):
            poly = to_screen(sh.outline(s))
            c.create_polygon(*poly, fill=fill, outline=outline, width=w, joinstyle="round",
                             tags=tags, **extra)
        elif typ == "rect":
            c.create_rectangle(*pts, fill=fill, outline=outline, width=w, tags=tags, **extra)
        elif typ == "ellipse":
            c.create_oval(*pts, fill=fill, outline=outline, width=w, tags=tags, **extra)
        elif typ in ("line", "pen"):
            if len(pts) == 2:
                pts = pts + pts
            col = stroke or fill or "#000000"
            line_extra = {"dash": dash} if dash else {}
            c.create_line(*pts, fill=col, width=max(1.0, max(sw, 1) * z), capstyle="round",
                          joinstyle="round", smooth=(typ == "pen"), tags=tags, **line_extra)
        elif typ == "polygon":
            if len(pts) >= 6:
                c.create_polygon(*pts, fill=fill, outline=outline, width=w, joinstyle="round",
                                 tags=tags, **extra)
        elif typ == "text":
            size = -max(1, int(round(sh.prop(s, "size") * z)))
            c.create_text(pts[0], pts[1], text=s.get("text", ""), anchor="nw",
                          angle=-sh.prop(s, "rot"),
                          fill=fill or stroke or "#000000", font=(ed.ui_font, size), tags=tags)

    def _draw_polygon_preview(self):
        ed, c = self.ed, self.c
        if ed.tool != "polygon" or not ed.poly_pts:
            return
        pts = ed.view.to_screen(ed.poly_pts + list(ed.cursor_w))
        if len(pts) >= 6 and ed.fill:
            c.create_polygon(*pts, fill=ed.fill, outline="", stipple="gray50" if not IS_MAC else "")
        c.create_line(*pts, fill=T["accent"], width=2, dash=(4, 3))
        sp = ed.view.to_screen(ed.poly_pts)
        for i in range(0, len(sp), 2):
            r = 6 if i == 0 else 4
            c.create_oval(sp[i] - r, sp[i + 1] - r, sp[i] + r, sp[i + 1] + r,
                          fill="#ffffff", outline=T["accent"], width=2)

    # ── overlays ────────────────────────────────────────────────────────────
    def _hover_box(self):
        ed, c = self.ed, self.c
        if ed.hover_id and ed.hover_id not in ed.selected and not ed.drag:
            s = ed.doc.by_id(ed.hover_id)
            if s:
                b = ed.view.to_screen(list(ed.shape_bbox(s)))
                c.create_rectangle(b[0] - 2, b[1] - 2, b[2] + 2, b[3] + 2, outline=T["accent2"], width=1)

    def _draw_selection_overlay(self):
        ed, c = self.ed, self.c
        acc = T["accent"]
        if ed.tool in ("select", "eyedropper"):
            self._hover_box()

        if ed.selected and ed.tool == "select":
            if len(ed.selected) > 1:
                for s in ed.selected_shapes():
                    b = ed.view.to_screen(list(ed.shape_bbox(s)))
                    c.create_rectangle(*b, outline=T["accent2"], dash=(3, 3))
            bb = ed.selection_bbox()
            if bb:
                sb = ed.view.to_screen(list(bb))
                x0, y0, x1, y1 = sb[0] - 1, sb[1] - 1, sb[2] + 1, sb[3] + 1
                c.create_rectangle(x0, y0, x1, y1, outline=acc, width=1.5)
                mode = ed.drag["mode"] if ed.drag else None
                if mode not in ("move", "rotate"):
                    for hx, hy in ed.handle_screen_points(x0, y0, x1, y1):
                        c.create_rectangle(hx - 4, hy - 4, hx + 4, hy + 4, fill="#ffffff",
                                           outline=acc, width=1.5)
                    rx, ry = ed.rotate_handle_screen(x0, y0, x1, y1)
                    c.create_line((x0 + x1) / 2, y0, rx, ry, fill=acc)
                    c.create_oval(rx - 5, ry - 5, rx + 5, ry + 5, fill="#ffffff", outline=acc, width=1.5)
                if mode == "rotate":
                    label = f"{ed.drag.get('angle', 0):.0f}°"
                else:
                    label = f"{bb[2] - bb[0]:.0f} × {bb[3] - bb[1]:.0f}"
                self._pill((x0 + x1) / 2, y1 + 18, label)

        if ed.drag and ed.drag["mode"] == "marquee":
            (sx, sy), (ex, ey) = ed.drag["start"], ed.drag["cur"]
            c.create_rectangle(sx, sy, ex, ey, outline=acc, dash=(4, 3), width=1)

    def _draw_direct_overlay(self):
        ed, c = self.ed, self.c
        acc = T["accent"]
        self._hover_box()
        active = ed.drag.get("idx") if ed.drag and ed.drag["mode"] == "anchor" else None
        for s in ed.selected_shapes():
            if s["type"] in ("ellipse", "text"):
                b = ed.view.to_screen(list(ed.shape_bbox(s)))
                c.create_rectangle(*b, outline=T["accent2"], dash=(3, 3))
                continue
            path = ed.view.to_screen(sh.outline(s))
            if len(path) >= 4:
                closed = s["type"] in ("polygon", "rect")
                c.create_line(*(path + path[:2] if closed else path), fill=acc, width=1)
            for i, (ax, ay) in enumerate(sh.anchors(s)):
                sx, sy = ed.view.to_screen([ax, ay])
                on = active == i and ed.drag.get("sid") == s["id"]
                c.create_rectangle(sx - 3.5, sy - 3.5, sx + 3.5, sy + 3.5,
                                   fill=acc if on else "#ffffff", outline=acc, width=1.2)
        if ed.drag and ed.drag["mode"] == "marquee":
            (sx, sy), (ex, ey) = ed.drag["start"], ed.drag["cur"]
            c.create_rectangle(sx, sy, ex, ey, outline=acc, dash=(4, 3), width=1)

    def _pill(self, x, y, label):
        c, ed = self.c, self.ed
        tid = c.create_text(x, y, text=label, fill="#ffffff", font=(ed.mono, 9))
        tb = c.bbox(tid)
        pill = c.create_rectangle(tb[0] - 7, tb[1] - 3, tb[2] + 7, tb[3] + 3, fill=T["accent"], outline="")
        c.tag_lower(pill, tid)
