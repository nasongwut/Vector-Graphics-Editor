"""Colours and fonts (dark theme)."""

from tkinter import font as tkfont

from vectra.config import IS_MAC

T = dict(
    bg="#0e1014",
    panel="#16191f",
    panel2="#1f232b",
    border="#2a2f3a",
    text="#e7e9ee",
    muted="#8a92a6",
    accent="#7c5cff",
    accent2="#a48dff",
    hover="#252a34",
    canvas="#0b0d11",
    grid="#151922",
    board_grid="#eef0f5",
    board="#ffffff",
    danger="#ff5c7a",
    danger_hover="#3a1f2a",
    shadow="#050609",
    entry="#11141a",
)

PALETTE = [
    "#0f172a", "#ffffff", "#f43f5e", "#f97316", "#facc15", "#22c55e",
    "#14b8a6", "#06b6d4", "#3b82f6", "#6366f1", "#7c5cff", "#a855f7",
    "#ec4899", "#64748b", "#cbd5e1", "#78350f",
]

_UI_FONTS = ("Segoe UI Variable Text", "Segoe UI", "SF Pro Text", ".AppleSystemUIFont",
             "Helvetica Neue", "Inter", "Noto Sans Thai", "Noto Sans", "Ubuntu",
             "DejaVu Sans", "Helvetica", "Arial")


def pick_font(root):
    fams = set(tkfont.families(root))
    for f in _UI_FONTS:
        if f in fams:
            return f
    return "TkDefaultFont"


def pick_mono_font(root):
    if "Consolas" in tkfont.families(root):
        return "Consolas"
    return "Menlo" if IS_MAC else "DejaVu Sans Mono"
