"""Mouse / tool interaction on the canvas."""

import copy
import math
from tkinter import simpledialog

from vectra.config import ALT_MASK, CONTROL_MASK, GRID, IS_MAC, SHIFT_MASK, STAR_INNER_RATIO
from vectra.i18n import tr
from vectra.model import geometry as geo
from vectra.model import shapes as sh
from vectra.ui.renderer import ROTATE
from vectra.ui.tools import cursor_for

ANCHOR_HIT = 6          # px
SEGMENT_HIT = 6         # px


class InteractionMixin:
    # ── wiring ──────────────────────────────────────────────────────────────
    def bind_canvas(self):
        c = self.canvas
        c.bind("<ButtonPress-1>", self.on_press)
        c.bind("<B1-Motion>", self.on_drag)
        c.bind("<ButtonRelease-1>", self.on_release)
        c.bind("<Double-Button-1>", self.on_double)
        c.bind("<Motion>", self.on_motion)
        c.bind("<Leave>", lambda e: self._set_hover(None))
        pan_btn, ctx_btn = ("3", "2") if IS_MAC else ("2", "3")
        c.bind(f"<ButtonPress-{pan_btn}>", self.pan_start)
        c.bind(f"<B{pan_btn}-Motion>", self.pan_move)
        c.bind(f"<ButtonRelease-{pan_btn}>", lambda e: self._end_pan())
        c.bind(f"<ButtonPress-{ctx_btn}>", self.context_menu)
        c.bind("<MouseWheel>", self.on_wheel)
        c.bind("<Shift-MouseWheel>", lambda e: self.on_wheel(e, horizontal=True))
        c.bind("<Control-MouseWheel>", lambda e: self.on_wheel(e, zoom=True))
        if IS_MAC:
            c.bind("<Command-MouseWheel>", lambda e: self.on_wheel(e, zoom=True))
        c.bind("<Button-4>", lambda e: self.on_wheel_linux(e, 1))
        c.bind("<Button-5>", lambda e: self.on_wheel_linux(e, -1))
        c.bind("<Configure>", lambda e: self.render())

    # ── tools & keys ────────────────────────────────────────────────────────
    def set_tool(self, tool):
        if self.tool == "polygon" and tool != "polygon":
            self.finish_polygon()
        self.tool = tool
        for k, b in self.tool_buttons.items():
            b.set_active(k == tool)
        self.canvas.config(cursor=cursor_for(tool))
        self.hover_id = None
        if self._flash_job:
            self.root.after_cancel(self._flash_job)
            self._flash_job = None
        self.render()

    def on_escape(self):
        if self.poly_pts:
            self.poly_pts = []
        elif self.drag:
            self.drag, self.temp = None, None
        else:
            self.selected.clear()
            self.on_selection_changed()
        self.render()

    def space_key(self, down):
        if down and not self.space:
            self.space = True
            self.canvas.config(cursor="fleur")
        elif not down:
            self.space = False
            self.restore_cursor()

    def arrow_key(self, dx, dy):
        """Arrows nudge the selection — except while drawing a star (↑/↓ = points)."""
        if self.drag and self.drag["mode"] == "star":
            if dy:
                self.star_points = max(3, min(30, self.star_points - (1 if dy > 0 else -1)))
                self._update_star()
                self.flash(tr("flash_star_points", n=self.star_points))
                self.render()
            return
        self.nudge(dx, dy)

    # ── hover ───────────────────────────────────────────────────────────────
    def on_motion(self, e):
        self.cursor_w = self.to_world(e.x, e.y)
        if self.tool == "polygon" and self.poly_pts:
            self.cursor_w = (self.snapv(self.cursor_w[0]), self.snapv(self.cursor_w[1]))
            self.render()
            return
        if self.tool in ("select", "direct", "eyedropper") and not self.space:
            h = self.handle_at(e.x, e.y) if (self.selected and self.tool == "select") else None
            if h == ROTATE:
                self.canvas.config(cursor="exchange")
                self._set_hover(None)
            elif h is not None:
                self.canvas.config(cursor="sizing")
                self._set_hover(None)
            elif self.tool == "direct" and self._anchor_at(e.x, e.y):
                self.canvas.config(cursor="dotbox")
                self._set_hover(None)
            else:
                sid = self.hit(e.x, e.y)
                if self.tool == "eyedropper":
                    self.canvas.config(cursor=cursor_for("eyedropper"))
                else:
                    self.canvas.config(cursor="fleur" if sid else "arrow")
                self._set_hover(sid)
        self.status_r.config(text=self.status_text())

    def _set_hover(self, sid):
        if sid != self.hover_id:
            self.hover_id = sid
            self.render()

    # ── panning ─────────────────────────────────────────────────────────────
    def pan_start(self, e):
        self.drag = {"mode": "pan", "last": (e.x, e.y)}
        self.canvas.config(cursor="fleur")

    def pan_move(self, e):
        if self.drag and self.drag["mode"] == "pan":
            lx, ly = self.drag["last"]
            self.view.pan(e.x - lx, e.y - ly)
            self.drag["last"] = (e.x, e.y)
            self.render()

    def _end_pan(self):
        self.drag = None
        self.restore_cursor()

    # ── press ───────────────────────────────────────────────────────────────
    def orig_shapes(self):
        return {s["id"]: copy.deepcopy(s) for s in self.selected_shapes()}

    def on_press(self, e):
        self.canvas.focus_set()
        if self.space or self.tool == "hand":
            self.pan_start(e)
            return
        wx, wy = self.to_world(e.x, e.y)
        sx, sy = self.snapv(wx), self.snapv(wy)
        t = self.tool
        shift = bool(e.state & SHIFT_MASK)
        alt = bool(e.state & ALT_MASK)

        if t == "select":
            self._press_select(e, wx, wy, shift)
        elif t == "direct":
            self._press_direct(e, wx, wy, shift, alt)
        elif t == "zoom":
            self.zoom_at(1 / 1.5 if alt else 1.5, e.x, e.y)
        elif t == "eyedropper":
            sid = self.hit(e.x, e.y)
            if sid:
                self.copy_appearance(self.doc.by_id(sid))
        elif t in ("rect", "ellipse", "line"):
            self.drag = {"mode": "draw", "start": (sx, sy)}
            self.temp = self.new_shape(t, [sx, sy, sx, sy])
        elif t == "star":
            self.drag = {"mode": "star", "center": (sx, sy), "r": 0.0}
            self.temp = self.new_shape("polygon", [sx, sy, sx, sy, sx, sy])
        elif t == "pen":
            self.drag = {"mode": "pen"}
            self.temp = self.new_shape("pen", [wx, wy])
        elif t == "polygon":
            if len(self.poly_pts) >= 6:
                fx, fy = self.to_screen(self.poly_pts[:2])
                if math.hypot(e.x - fx, e.y - fy) < 9:
                    self.finish_polygon()
                    return
            self.poly_pts += [sx, sy]
            self.cursor_w = (sx, sy)
            self.render()
        elif t == "text":
            self.add_text(sx, sy)

    def _press_select(self, e, wx, wy, shift):
        h = self.handle_at(e.x, e.y)
        if h == ROTATE:
            bb = self.selection_bbox()
            cx, cy = geo.bbox_center(bb)
            self.drag = {"mode": "rotate", "center": (cx, cy), "angle": 0.0,
                         "start": math.degrees(math.atan2(wy - cy, wx - cx)),
                         "orig": self.orig_shapes(), "changed": False}
            return
        if h is not None:
            self.drag = {"mode": "resize", "h": h, "bbox": self.selection_bbox(),
                         "orig": self.orig_shapes(), "changed": False}
            return
        sid = self.hit(e.x, e.y)
        if sid:
            ids = self.doc.expand_groups({sid})
            if shift:
                if sid in self.selected:
                    self.selected -= ids
                else:
                    self.selected |= ids
            elif sid not in self.selected:
                self.selected = ids
            self.drag = {"mode": "move", "start": (wx, wy), "orig": self.orig_shapes(), "changed": False}
        else:
            if not shift:
                self.selected = set()
            self.drag = {"mode": "marquee", "start": (e.x, e.y), "cur": (e.x, e.y),
                         "base": set(self.selected)}
        self.on_selection_changed()
        self.render()

    def _anchor_at(self, x, y):
        """(shape id, anchor index) under the screen point among selected shapes."""
        for s in reversed(self.selected_shapes()):
            for i, (ax, ay) in enumerate(sh.anchors(s)):
                px, py = self.to_screen([ax, ay])
                if abs(px - x) <= ANCHOR_HIT and abs(py - y) <= ANCHOR_HIT:
                    return s["id"], i
        return None

    def _press_direct(self, e, wx, wy, shift, alt):
        found = self._anchor_at(e.x, e.y)
        if found:
            sid, idx = found
            if alt:
                self.delete_anchor(sid, idx)
                return
            self.drag = {"mode": "anchor", "sid": sid, "idx": idx, "changed": False}
            self.render()
            return
        sid = self.hit(e.x, e.y)
        if sid:
            if shift:
                self.selected ^= {sid}
            elif sid not in self.selected:
                self.selected = {sid}
            self.drag = {"mode": "move", "start": (wx, wy), "orig": self.orig_shapes(), "changed": False}
        else:
            if not shift:
                self.selected = set()
            self.drag = {"mode": "marquee", "start": (e.x, e.y), "cur": (e.x, e.y),
                         "base": set(self.selected)}
        self.on_selection_changed()
        self.render()

    # ── drag ────────────────────────────────────────────────────────────────
    def _begin_change(self, d):
        if not d["changed"]:
            self.push_undo()
            d["changed"] = True

    def _apply_from_orig(self, d, fn):
        for sid, orig in d["orig"].items():
            s = self.doc.by_id(sid)
            if s is not None:
                sh.replace_in_place(s, fn(orig))

    def on_drag(self, e):
        d = self.drag
        if not d:
            return
        if d["mode"] == "pan":
            self.pan_move(e)
            return
        wx, wy = self.to_world(e.x, e.y)
        self.cursor_w = (wx, wy)
        shift = bool(e.state & SHIFT_MASK)
        mode = d["mode"]

        if mode == "move":
            dx, dy = wx - d["start"][0], wy - d["start"][1]
            if self.snap:
                dx, dy = round(dx / GRID) * GRID, round(dy / GRID) * GRID
            if shift:  # constrain to axis
                if abs(dx) > abs(dy):
                    dy = 0
                else:
                    dx = 0
            if dx or dy:
                self._begin_change(d)
            if d["changed"]:
                for sid, orig in d["orig"].items():
                    s = self.doc.by_id(sid)
                    s["pts"] = geo.translate_pts(orig["pts"], dx, dy)

        elif mode == "resize":
            nb = geo.resize_bbox(d["bbox"], d["h"], self.snapv(wx), self.snapv(wy), shift)
            self._begin_change(d)
            self._apply_from_orig(d, lambda o: sh.scaled(o, d["bbox"], nb))

        elif mode == "rotate":
            cx, cy = d["center"]
            ang = math.degrees(math.atan2(wy - cy, wx - cx)) - d["start"]
            if shift:
                ang = round(ang / 15.0) * 15.0
            ang = geo.normalize_angle(ang)
            d["angle"] = ang
            if ang:
                self._begin_change(d)
            self._apply_from_orig(d, lambda o: sh.rotated(o, ang, cx, cy))

        elif mode == "anchor":
            s = self.doc.by_id(d["sid"])
            if s is not None:
                if not d["changed"]:
                    self._begin_change(d)
                    if s["type"] == "rect":
                        sh.replace_in_place(s, sh.to_path(s))
                i = d["idx"]
                s["pts"][2 * i] = self.snapv(wx)
                s["pts"][2 * i + 1] = self.snapv(wy)

        elif mode == "marquee":
            d["cur"] = (e.x, e.y)

        elif mode == "draw":
            x0, y0 = d["start"]
            x1, y1 = self.snapv(wx), self.snapv(wy)
            if shift:
                if self.temp["type"] == "line":
                    x1, y1 = geo.constrain_45(x0, y0, x1, y1)
                else:
                    x1, y1 = geo.constrain_square(x0, y0, x1, y1)
            self.temp["pts"] = [x0, y0, x1, y1]

        elif mode == "star":
            cx, cy = d["center"]
            d["r"] = math.hypot(self.snapv(wx) - cx, self.snapv(wy) - cy)
            self._update_star()

        elif mode == "pen":
            lx, ly = self.temp["pts"][-2:]
            if math.hypot(wx - lx, wy - ly) * self.view.zoom > 2:
                self.temp["pts"] += [wx, wy]
        self.render()

    def _update_star(self, radius=None):
        d = self.drag
        if not d or d["mode"] != "star" or not self.temp:
            return
        cx, cy = d["center"]
        r = d["r"] if radius is None else radius
        self.temp["pts"] = geo.star_points(cx, cy, r, r * STAR_INNER_RATIO, self.star_points)

    # ── release ─────────────────────────────────────────────────────────────
    def on_release(self, e):
        d = self.drag
        if not d:
            return
        mode = d["mode"]
        if mode == "pan":
            self._end_pan()
            return
        if mode == "marquee":
            (sx, sy), (ex, ey) = d["start"], d["cur"]
            if abs(ex - sx) > 2 or abs(ey - sy) > 2:
                x0, y0 = self.to_world(min(sx, ex), min(sy, ey))
                x1, y1 = self.to_world(max(sx, ex), max(sy, ey))
                hits = set()
                for s in self.doc.editable():
                    b = self.shape_bbox(s)
                    if b[0] <= x1 and b[2] >= x0 and b[1] <= y1 and b[3] >= y0:
                        hits.add(s["id"])
                if self.tool == "select":
                    hits = self.doc.expand_groups(hits)
                self.selected = d["base"] | hits
        elif mode == "draw":
            x0, y0, x1, y1 = self.temp["pts"]
            tiny = math.hypot(x1 - x0, y1 - y0) * self.view.zoom < 4
            if tiny and self.temp["type"] in ("rect", "ellipse"):
                self.temp["pts"] = [x0 - 60, y0 - 60, x0 + 60, y0 + 60]
                tiny = False
            if not tiny:
                self.add_shape(self.temp)
        elif mode == "star":
            if d["r"] * self.view.zoom < 4:
                self._update_star(radius=60)
            self.add_shape(self.temp)
        elif mode == "pen":
            if len(self.temp["pts"]) >= 4:
                self.add_shape(self.temp)
        self.drag, self.temp = None, None
        self.on_selection_changed()
        self.render()

    # ── double click ────────────────────────────────────────────────────────
    def on_double(self, e):
        if self.tool == "polygon":
            # the second press of the double-click already added a duplicate point
            if len(self.poly_pts) >= 4 and self.poly_pts[-2:] == self.poly_pts[-4:-2]:
                self.poly_pts = self.poly_pts[:-2]
            self.finish_polygon()
        elif self.tool == "direct":
            self.drag = None
            self.insert_anchor_at(e.x, e.y)
        elif self.tool == "select":
            sid = self.hit(e.x, e.y)
            s = self.doc.by_id(sid) if sid else None
            if s and s["type"] == "text":
                self.drag = None
                txt = simpledialog.askstring(tr("edit_text_title"), tr("edit_text_prompt"),
                                             initialvalue=s["text"], parent=self.root)
                if txt:
                    self.push_undo()
                    s["text"] = txt
                    self.on_selection_changed()
                    self.render()

    # ── anchors (direct selection) ──────────────────────────────────────────
    def delete_anchor(self, sid, idx):
        s = self.doc.by_id(sid)
        if s is None:
            return
        min_pts = {"polygon": 3, "rect": 3, "pen": 2}.get(s["type"])
        n_pts = len(sh.anchors(s))
        if min_pts is None or n_pts - 1 < min_pts:
            return
        self.push_undo()
        if s["type"] == "rect":
            sh.replace_in_place(s, sh.to_path(s))
        del s["pts"][2 * idx:2 * idx + 2]
        self.render()

    def insert_anchor_at(self, x, y):
        best = None
        wx, wy = self.to_world(x, y)
        for s in reversed(self.selected_shapes()):
            if s["type"] not in ("polygon", "pen", "rect"):
                continue
            pts = sh.outline(s) if s["type"] != "rect" else sh.corner_points(s)
            res = geo.nearest_segment(pts, wx, wy, closed=s["type"] != "pen")
            if res and res[1] * self.view.zoom <= SEGMENT_HIT and (best is None or res[1] < best[1][1]):
                best = (s, res)
        if not best:
            return
        s, (index, _d, qx, qy) = best
        self.push_undo()
        if s["type"] == "rect":
            sh.replace_in_place(s, sh.to_path(s))
        s["pts"][2 * index:2 * index] = [qx, qy]
        self.render()

    # ── wheel / context menu ────────────────────────────────────────────────
    def on_wheel(self, e, horizontal=False, zoom=False):
        delta = e.delta
        if not IS_MAC:
            delta = delta / 120
        if zoom:
            self.zoom_at(1.1 ** delta, e.x, e.y)
            return
        amount = delta * (12 if IS_MAC else 40)
        if horizontal:
            self.view.pan(amount, 0)
        else:
            self.view.pan(0, amount)
        self.render()

    def on_wheel_linux(self, e, direction):
        if e.state & CONTROL_MASK:
            self.zoom_at(1.1 ** direction, e.x, e.y)
        elif e.state & SHIFT_MASK:
            self.view.pan(direction * 40, 0)
            self.render()
        else:
            self.view.pan(0, direction * 40)
            self.render()

    def context_menu(self, e):
        sid = self.hit(e.x, e.y)
        if sid and sid not in self.selected:
            self.selected = self.doc.expand_groups({sid}) if self.tool != "direct" else {sid}
            self.on_selection_changed()
            self.render()
        try:
            self.menu.tk_popup(e.x_root, e.y_root)
        finally:
            self.menu.grab_release()
