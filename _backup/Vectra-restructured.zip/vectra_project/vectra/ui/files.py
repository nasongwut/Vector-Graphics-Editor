"""New / open / save / export / close."""

import os
from tkinter import filedialog, messagebox

from vectra.config import ARTBOARD
from vectra.fileio import json_io, svg_export
from vectra.i18n import tr


class FilesMixin:
    def confirm_discard(self):
        if not self.dirty or not self.doc.shapes:
            return True
        r = messagebox.askyesnocancel(tr("save_q_title"), tr("save_q_msg"), parent=self.root)
        if r is None:
            return False
        if r:
            return self.save()
        return True

    def _reset(self, shapes, path):
        self.doc.clear()
        if shapes:
            self.doc.load(shapes)
        self.selected = set()
        self.history.clear()
        self.file_path = path
        self.dirty = False
        self.update_title()
        self.on_selection_changed()
        self.zoom_fit()

    def new_doc(self):
        if self.confirm_discard():
            self._reset([], None)

    def save(self, save_as=False):
        if save_as or not self.file_path:
            p = filedialog.asksaveasfilename(parent=self.root, defaultextension=".json",
                                             filetypes=[(tr("ft_json"), "*.json")],
                                             title=tr("dlg_save_title"))
            if not p:
                return False
            self.file_path = p
        try:
            json_io.save(self.file_path, self.doc.shapes, ARTBOARD)
        except OSError as ex:
            messagebox.showerror(tr("save_failed"), str(ex), parent=self.root)
            return False
        self.dirty = False
        self.update_title()
        self.flash(tr("flash_saved", name=os.path.basename(self.file_path)))
        return True

    def open_doc(self):
        if not self.confirm_discard():
            return
        p = filedialog.askopenfilename(parent=self.root, title=tr("dlg_open_title"),
                                       filetypes=[(tr("ft_json"), "*.json"), (tr("ft_all"), "*.*")])
        if not p:
            return
        try:
            shapes = json_io.load(p)
        except Exception as ex:  # noqa: BLE001 - any bad file -> friendly message
            messagebox.showerror(tr("open_failed"), f"{tr('invalid_file')}\n{ex}", parent=self.root)
            return
        self._reset(shapes, p)
        self.flash(tr("flash_opened", name=os.path.basename(p)))

    def export_svg(self, path=None):
        if path is None:
            path = filedialog.asksaveasfilename(parent=self.root, defaultextension=".svg",
                                                filetypes=[("SVG", "*.svg")], title=tr("dlg_export_title"))
            if not path:
                return
        try:
            svg_export.export(path, self.doc.shapes, ARTBOARD, self.ui_font)
        except OSError as ex:
            messagebox.showerror(tr("export_failed"), str(ex), parent=self.root)
            return
        self.flash(tr("flash_exported", name=os.path.basename(path)))

    def on_close(self):
        if self.confirm_discard():
            self.root.destroy()
