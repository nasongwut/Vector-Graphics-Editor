"""Keyboard shortcuts (bound on the root window)."""

import tkinter as tk

from vectra.config import IS_MAC
from vectra.ui.tools import TOOLS


def _typing(e):
    """True while the user is typing in a text field — shortcuts must not fire."""
    return isinstance(e.widget, (tk.Entry, tk.Text, tk.Spinbox))


def bind_shortcuts(ed):
    r = ed.root
    mods = ["Control"] + (["Command"] if IS_MAC else [])
    alt = "Option" if IS_MAC else "Alt"

    def on(sequence, fn, break_=True):
        def handler(e):
            if _typing(e):
                return None
            fn()
            return "break" if break_ else None
        r.bind(sequence, handler)

    def sc(key, fn, with_alt=False):
        for m in mods:
            on(f"<{m}-{alt}-Key-{key}>" if with_alt else f"<{m}-Key-{key}>", fn)

    # file / edit
    sc("z", ed.undo)
    sc("Z", ed.redo)
    sc("y", ed.redo)
    sc("c", ed.copy_sel)
    sc("v", ed.paste)
    sc("d", ed.duplicate)
    sc("a", ed.select_all)
    sc("s", ed.save)
    sc("S", lambda: ed.save(True))
    sc("o", ed.open_doc)
    sc("n", ed.new_doc)
    sc("e", ed.export_svg)
    # object
    sc("g", ed.group_sel)
    sc("G", ed.ungroup_sel)
    sc("2", ed.lock_sel)
    sc("2", ed.unlock_all, with_alt=True)
    sc("3", ed.hide_sel)
    sc("3", ed.show_all, with_alt=True)
    # view
    sc("0", ed.zoom_fit)
    sc("1", lambda: ed.set_zoom(1.0))
    sc("equal", lambda: ed.zoom_center(1.2))
    sc("plus", lambda: ed.zoom_center(1.2))
    sc("minus", lambda: ed.zoom_center(1 / 1.2))
    sc("apostrophe", ed.toggle_grid)
    sc("semicolon", ed.toggle_snap)

    # tools (single letters)
    for item in TOOLS:
        if item:
            k = item[3].lower()
            on(f"<KeyPress-{k}>", lambda t=item[0]: ed.set_tool(t), break_=False)
            on(f"<KeyPress-{k.upper()}>", lambda t=item[0]: ed.set_tool(t), break_=False)
    on("<KeyPress-d>", ed.default_colors, break_=False)
    on("<KeyPress-X>", ed.swap_colors, break_=False)

    on("<Delete>", ed.delete_sel, break_=False)
    on("<BackSpace>", ed.delete_sel, break_=False)
    on("<Escape>", ed.on_escape, break_=False)
    on("<Return>", ed.finish_polygon, break_=False)
    on("<bracketright>", ed.bring_forward, break_=False)
    on("<bracketleft>", ed.send_backward, break_=False)
    on("<braceright>", ed.bring_front, break_=False)
    on("<braceleft>", ed.send_back, break_=False)
    for key, dx, dy in (("Left", -1, 0), ("Right", 1, 0), ("Up", 0, -1), ("Down", 0, 1)):
        on(f"<{key}>", lambda a=dx, b=dy: ed.arrow_key(a, b), break_=False)
        on(f"<Shift-{key}>", lambda a=dx, b=dy: ed.arrow_key(a * 10, b * 10), break_=False)

    def space(down):
        def handler(e):
            if not _typing(e):
                ed.space_key(down)
        return handler
    r.bind("<KeyPress-space>", space(True))
    r.bind("<KeyRelease-space>", space(False))
