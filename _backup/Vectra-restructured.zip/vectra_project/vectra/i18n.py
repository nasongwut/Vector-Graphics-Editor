"""Bilingual UI strings (Thai / English).

Usage::

    from vectra.i18n import tr
    tr("btn_save")                 # -> "บันทึก" or "Save"
    tr("flash_copied", n=3)        # -> "คัดลอก 3 วัตถุ" / "Copied 3 objects"

Add a string by adding one entry to ``STRINGS``: ``key: (thai, english)``.
"""

LANGUAGES = {"th": "ไทย", "en": "English"}
DEFAULT_LANGUAGE = "th"
_ORDER = ("th", "en")

_current = DEFAULT_LANGUAGE

STRINGS = {
    # ── app / top bar ──────────────────────────────────────────────────────
    "app_subtitle": ("Vector Editor", "Vector Editor"),
    "untitled": ("ไม่มีชื่อ", "Untitled"),
    "btn_new": ("ใหม่", "New"),
    "tip_new": ("เอกสารใหม่  (Ctrl+N)", "New document  (Ctrl+N)"),
    "btn_open": ("เปิด", "Open"),
    "tip_open": ("เปิดไฟล์ .json  (Ctrl+O)", "Open a .json file  (Ctrl+O)"),
    "btn_save": ("บันทึก", "Save"),
    "tip_save": ("บันทึก  (Ctrl+S)", "Save  (Ctrl+S)"),
    "btn_save_as": ("บันทึกเป็น", "Save As"),
    "tip_save_as": ("บันทึกเป็นไฟล์ใหม่  (Ctrl+Shift+S)", "Save to a new file  (Ctrl+Shift+S)"),
    "tip_undo": ("ย้อนกลับ  (Ctrl+Z)", "Undo  (Ctrl+Z)"),
    "tip_redo": ("ทำซ้ำ  (Ctrl+Y)", "Redo  (Ctrl+Y)"),
    "btn_export": ("ส่งออก SVG", "Export SVG"),
    "tip_export": ("ส่งออกเป็นไฟล์ .svg  (Ctrl+E)", "Export as .svg  (Ctrl+E)"),
    "tip_zoom100": ("คลิกเพื่อซูม 100%  (Ctrl+1)", "Click for 100%  (Ctrl+1)"),
    "btn_fit": ("พอดีจอ", "Fit"),
    "tip_fit": ("ซูมให้พอดีหน้าจอ  (Ctrl+0)", "Zoom to fit  (Ctrl+0)"),
    "tip_lang": ("เปลี่ยนภาษา / Switch language", "Switch language / เปลี่ยนภาษา"),

    # ── tools ──────────────────────────────────────────────────────────────
    "tool_select": ("เลือก / ย้าย / ย่อขยาย / หมุน", "Selection — move, scale, rotate"),
    "tool_direct": ("เลือกจุด (แก้ไข anchor)", "Direct Selection — edit anchors"),
    "tool_hand": ("เลื่อนมุมมอง", "Hand"),
    "tool_zoom": ("ซูม", "Zoom"),
    "tool_rect": ("สี่เหลี่ยม", "Rectangle"),
    "tool_ellipse": ("วงรี", "Ellipse"),
    "tool_line": ("เส้นตรง", "Line"),
    "tool_polygon": ("รูปหลายเหลี่ยม", "Polygon"),
    "tool_star": ("รูปดาว", "Star"),
    "tool_pen": ("ปากกาวาดอิสระ", "Pencil"),
    "tool_text": ("ข้อความ", "Type"),
    "tool_eyedropper": ("ดูดสี (คัดลอกลักษณะ)", "Eyedropper — copy appearance"),

    "hint_select": ("คลิกเพื่อเลือก · Shift+คลิก เพิ่มการเลือก · ลากที่ว่างเพื่อเลือกเป็นกรอบ · "
                    "ลากจุดวงกลมด้านบนเพื่อหมุน · ดับเบิลคลิกข้อความเพื่อแก้ไข",
                    "Click to select · Shift+click to add · drag empty space to marquee · "
                    "drag the round handle to rotate · double-click text to edit"),
    "hint_direct": ("คลิกวัตถุเพื่อแสดงจุด · ลากจุดเพื่อแก้รูปทรง · Alt+คลิกจุด = ลบจุด · "
                    "ดับเบิลคลิกบนเส้น = เพิ่มจุด",
                    "Click an object to show anchors · drag an anchor to reshape · "
                    "Alt+click anchor = delete · double-click a segment = add anchor"),
    "hint_hand": ("ลากเพื่อเลื่อนมุมมอง · Ctrl+ล้อเมาส์ เพื่อซูม",
                  "Drag to pan · Ctrl+wheel to zoom"),
    "hint_zoom": ("คลิก = ซูมเข้า · Alt+คลิก = ซูมออก", "Click to zoom in · Alt+click to zoom out"),
    "hint_rect": ("ลากเพื่อวาดสี่เหลี่ยม · Shift = จัตุรัส · คลิกครั้งเดียว = ขนาดเริ่มต้น · "
                  "ปรับ ‘มุมมน’ ในแผงคุณสมบัติ",
                  "Drag to draw · Shift = square · single click = default size · "
                  "set ‘Corner radius’ in Properties"),
    "hint_ellipse": ("ลากเพื่อวาดวงรี · Shift = วงกลม", "Drag to draw · Shift = circle"),
    "hint_line": ("ลากเพื่อวาดเส้น · Shift = ล็อกมุม 45°", "Drag to draw · Shift = snap to 45°"),
    "hint_polygon": ("คลิกเพื่อวางจุด · คลิกจุดแรก / ดับเบิลคลิก / Enter เพื่อจบ · Esc ยกเลิก",
                     "Click to add points · click the first point / double-click / Enter to "
                     "finish · Esc to cancel"),
    "hint_star": ("ลากจากจุดศูนย์กลาง · ระหว่างลากกด ↑ / ↓ เพื่อเพิ่ม/ลดแฉก",
                  "Drag from the centre · press ↑ / ↓ while dragging to change points"),
    "hint_pen": ("กดค้างแล้วลากเพื่อวาดเส้นอิสระ", "Press and drag to draw freehand"),
    "hint_text": ("คลิกตำแหน่งที่ต้องการวางข้อความ", "Click where the text should go"),
    "hint_eyedropper": ("คลิกวัตถุเพื่อคัดลอกสี/เส้นไปยังวัตถุที่เลือก (หรือใช้กับวัตถุใหม่)",
                        "Click an object to copy its fill/stroke to the selection (or to new "
                        "objects)"),

    # ── shape types ────────────────────────────────────────────────────────
    "type_rect": ("สี่เหลี่ยม", "Rectangle"),
    "type_ellipse": ("วงรี", "Ellipse"),
    "type_line": ("เส้นตรง", "Line"),
    "type_polygon": ("รูปหลายเหลี่ยม", "Polygon"),
    "type_pen": ("เส้นอิสระ", "Path"),
    "type_text": ("ข้อความ", "Text"),

    # ── right panel ────────────────────────────────────────────────────────
    "tab_props": ("คุณสมบัติ", "Properties"),
    "tab_arrange": ("จัดวาง", "Arrange"),
    "tab_layers": ("เลเยอร์", "Layers"),

    "sec_selection": ("การเลือก", "SELECTION"),
    "sec_transform": ("ตำแหน่ง / ขนาด", "TRANSFORM"),
    "sec_appearance": ("ลักษณะ", "APPEARANCE"),
    "sec_align": ("จัดแนว", "ALIGN"),
    "sec_arrange": ("ลำดับชั้น", "ARRANGE"),
    "sec_object": ("วัตถุ", "OBJECT"),
    "sec_view": ("มุมมอง", "VIEW"),
    "sec_layers": ("วัตถุทั้งหมด (บนสุดอยู่ด้านบน)", "ALL OBJECTS (top first)"),

    "no_selection": ("ไม่ได้เลือกวัตถุ", "No selection"),
    "no_selection_hint": ("ค่าด้านล่างจะใช้กับวัตถุที่วาดใหม่", "Values below apply to new objects"),
    "n_selected": ("เลือก {n} วัตถุ", "{n} objects selected"),
    "group_of": ("กลุ่ม ({n} วัตถุ)", "Group ({n} objects)"),

    "fill": ("สีพื้น", "Fill"),
    "stroke": ("สีเส้น", "Stroke"),
    "none": ("ไม่มี", "None"),
    "stroke_width": ("ความหนาเส้น", "Stroke width"),
    "font_size": ("ขนาดตัวอักษร", "Font size"),
    "corner_radius": ("มุมมน (สี่เหลี่ยม)", "Corner radius"),
    "dashed": ("เส้นประ", "Dashed"),
    "tip_dashed": ("สลับเส้นทึบ / เส้นประ", "Toggle solid / dashed stroke"),
    "swap": ("⇄ สลับสี", "⇄ Swap"),
    "tip_swap": ("สลับสีพื้นกับสีเส้น  (Shift+X)", "Swap fill and stroke  (Shift+X)"),
    "default_colors": ("สีเริ่มต้น", "Default"),
    "tip_default_colors": ("สีพื้นขาว เส้นดำ  (D)", "White fill, black stroke  (D)"),
    "palette_hint": ("จานสี  ·  คลิกซ้าย = พื้น  ·  คลิกขวา = เส้น",
                     "Swatches  ·  left-click = fill  ·  right-click = stroke"),
    "angle": ("มุม°", "Angle°"),
    "tip_transform": ("พิมพ์ค่าแล้วกด Enter", "Type a value and press Enter"),

    "align_left": ("ชิดซ้าย", "Align left"),
    "align_hcenter": ("กึ่งกลางแนวนอน", "Align horizontal centres"),
    "align_right": ("ชิดขวา", "Align right"),
    "align_top": ("ชิดบน", "Align top"),
    "align_vcenter": ("กึ่งกลางแนวตั้ง", "Align vertical centres"),
    "align_bottom": ("ชิดล่าง", "Align bottom"),
    "distribute_h": ("⇹ กระจายแนวนอน", "⇹ Distribute H"),
    "distribute_v": ("⇳ กระจายแนวตั้ง", "⇳ Distribute V"),
    "tip_distribute": ("ต้องเลือกอย่างน้อย 3 ชิ้น", "Needs 3 or more objects"),
    "align_to_artboard": ("เลือก 1 ชิ้น = จัดตาม Artboard · หลายชิ้น = จัดตามกรอบการเลือก",
                          "1 object = align to artboard · several = align to selection"),

    "bring_front": ("⤒ หน้าสุด", "⤒ To front"),
    "bring_forward": ("↑ ขึ้น", "↑ Forward"),
    "send_backward": ("↓ ลง", "↓ Backward"),
    "send_back": ("⤓ หลังสุด", "⤓ To back"),
    "duplicate": ("⧉ ทำสำเนา", "⧉ Duplicate"),
    "delete": ("✕ ลบ", "✕ Delete"),
    "group": ("▣ จัดกลุ่ม", "▣ Group"),
    "ungroup": ("▢ แยกกลุ่ม", "▢ Ungroup"),
    "flip_h": ("⇋ พลิกแนวนอน", "⇋ Flip H"),
    "flip_v": ("⇵ พลิกแนวตั้ง", "⇵ Flip V"),
    "rotate_ccw": ("↺ หมุน -90°", "↺ Rotate -90°"),
    "rotate_cw": ("↻ หมุน 90°", "↻ Rotate 90°"),
    "lock": ("🔒 ล็อก", "🔒 Lock"),
    "unlock_all": ("🔓 ปลดล็อกทั้งหมด", "🔓 Unlock all"),
    "hide": ("◌ ซ่อน", "◌ Hide"),
    "show_all": ("◉ แสดงทั้งหมด", "◉ Show all"),
    "grid": ("▦ กริด", "▦ Grid"),
    "snap": ("⌗ Snap", "⌗ Snap"),
    "tip_grid": ("แสดง/ซ่อนกริด  (Ctrl+')", "Show/hide grid  (Ctrl+')"),
    "tip_snap": ("ยึดตามกริด  (Ctrl+;)", "Snap to grid  (Ctrl+;)"),
    "panel_footer": ("Ctrl+ล้อเมาส์ = ซูม   ·   Space+ลาก = เลื่อน",
                     "Ctrl+wheel = zoom   ·   Space+drag = pan"),

    "layers_empty": ("ยังไม่มีวัตถุ", "No objects yet"),
    "tip_eye": ("แสดง / ซ่อน", "Show / hide"),
    "tip_lock": ("ล็อก / ปลดล็อก", "Lock / unlock"),
    "rename_title": ("เปลี่ยนชื่อ", "Rename"),
    "rename_prompt": ("ชื่อวัตถุ:", "Object name:"),
    "layers_hint": ("คลิก = เลือก · Shift+คลิก = เพิ่ม · ดับเบิลคลิก = เปลี่ยนชื่อ",
                    "Click = select · Shift+click = add · double-click = rename"),

    # ── context menu ───────────────────────────────────────────────────────
    "menu_copy": ("คัดลอก", "Copy"),
    "menu_paste": ("วาง", "Paste"),
    "menu_duplicate": ("ทำสำเนา", "Duplicate"),
    "menu_group": ("จัดกลุ่ม", "Group"),
    "menu_ungroup": ("แยกกลุ่ม", "Ungroup"),
    "menu_bring_front": ("ขึ้นหน้าสุด", "Bring to Front"),
    "menu_bring_forward": ("ขึ้น 1 ชั้น", "Bring Forward"),
    "menu_send_backward": ("ลง 1 ชั้น", "Send Backward"),
    "menu_send_back": ("ส่งไปหลังสุด", "Send to Back"),
    "menu_flip_h": ("พลิกแนวนอน", "Flip Horizontal"),
    "menu_flip_v": ("พลิกแนวตั้ง", "Flip Vertical"),
    "menu_lock": ("ล็อก", "Lock"),
    "menu_hide": ("ซ่อน", "Hide"),
    "menu_delete": ("ลบ", "Delete"),

    # ── dialogs ────────────────────────────────────────────────────────────
    "text_title": ("ข้อความ", "Text"),
    "text_prompt": ("พิมพ์ข้อความ:", "Enter text:"),
    "edit_text_title": ("แก้ไขข้อความ", "Edit text"),
    "edit_text_prompt": ("ข้อความ:", "Text:"),
    "save_q_title": ("บันทึกงาน?", "Save changes?"),
    "save_q_msg": ("มีการแก้ไขที่ยังไม่ได้บันทึก\nต้องการบันทึกก่อนหรือไม่?",
                   "You have unsaved changes.\nSave them first?"),
    "save_failed": ("บันทึกไม่สำเร็จ", "Could not save"),
    "open_failed": ("เปิดไฟล์ไม่สำเร็จ", "Could not open file"),
    "invalid_file": ("ไฟล์ไม่ถูกต้อง", "The file is not a valid Vectra drawing"),
    "export_failed": ("ส่งออกไม่สำเร็จ", "Could not export"),
    "dlg_save_title": ("บันทึกงาน", "Save drawing"),
    "dlg_open_title": ("เปิดงาน", "Open drawing"),
    "dlg_export_title": ("ส่งออก SVG", "Export SVG"),
    "ft_json": ("ไฟล์งาน Vectra (JSON)", "Vectra drawing (JSON)"),
    "ft_all": ("ทุกไฟล์", "All files"),
    "pick_fill": ("เลือกสีพื้น", "Choose fill colour"),
    "pick_stroke": ("เลือกสีเส้น", "Choose stroke colour"),

    # ── status / flash messages ────────────────────────────────────────────
    "status_objects": ("{n} วัตถุ", "{n} objects"),
    "artboard": ("Artboard   {w} × {h}", "Artboard   {w} × {h}"),
    "flash_undo": ("ย้อนกลับ", "Undo"),
    "flash_redo": ("ทำซ้ำ", "Redo"),
    "flash_duplicated": ("ทำสำเนาแล้ว", "Duplicated"),
    "flash_copied": ("คัดลอก {n} วัตถุ", "Copied {n} objects"),
    "flash_saved": ("บันทึกแล้ว: {name}", "Saved: {name}"),
    "flash_opened": ("เปิด {name}", "Opened {name}"),
    "flash_exported": ("ส่งออก SVG แล้ว: {name}", "Exported SVG: {name}"),
    "flash_snap_on": ("เปิด Snap", "Snap on"),
    "flash_snap_off": ("ปิด Snap", "Snap off"),
    "flash_grouped": ("จัดกลุ่ม {n} วัตถุ", "Grouped {n} objects"),
    "flash_ungrouped": ("แยกกลุ่มแล้ว", "Ungrouped"),
    "flash_locked": ("ล็อก {n} วัตถุ", "Locked {n} objects"),
    "flash_unlocked": ("ปลดล็อกทั้งหมด", "Unlocked all"),
    "flash_hidden": ("ซ่อน {n} วัตถุ", "Hid {n} objects"),
    "flash_shown": ("แสดงทั้งหมด", "Showing all"),
    "flash_star_points": ("แฉก: {n}", "Points: {n}"),
    "flash_appearance": ("คัดลอกลักษณะแล้ว", "Appearance copied"),
    "flash_lang": ("ภาษา: ไทย", "Language: English"),
}


def set_language(lang):
    global _current
    _current = lang if lang in LANGUAGES else DEFAULT_LANGUAGE


def get_language():
    return _current


def next_language():
    i = _ORDER.index(_current)
    return _ORDER[(i + 1) % len(_ORDER)]


def tr(key, **kwargs):
    """Translate ``key`` into the current language; unknown keys return the key."""
    entry = STRINGS.get(key)
    if entry is None:
        return key
    text = entry[_ORDER.index(_current)]
    return text.format(**kwargs) if kwargs else text
