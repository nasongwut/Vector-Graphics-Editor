"""Shape records.

A shape is a plain JSON-serialisable dict so documents save/undo trivially::

    {"id": 3, "type": "rect", "pts": [x0, y0, x1, y1],
     "fill": "#7c5cff", "stroke": "#0f172a", "width": 2,
     # optional keys (absent = default, see DEFAULTS)
     "rot": 0, "radius": 0, "dash": False, "hidden": False, "locked": False,
     "gid": None, "name": "", "size": 32, "text": "..."}

Geometry by type
  rect / ellipse  pts = two opposite corners of the *unrotated* box, ``rot`` turns
                  it around its centre (live rotation, like Illustrator).
  line / polygon / pen
                  pts = the anchor points; rotation is baked into the points and
                  ``rot`` only records the accumulated angle for the UI.
  text            pts = top-left anchor; ``rot`` turns around that anchor.
"""

import copy
import math

from vectra.i18n import tr
from vectra.model import geometry as g

SHAPE_TYPES = ("rect", "ellipse", "line", "polygon", "pen", "text")
POINT_TYPES = ("line", "polygon", "pen")      # geometry == the point list
STROKE_ONLY = ("line", "pen")                 # never filled
BOX_TYPES = ("rect", "ellipse")

DEFAULTS = {"rot": 0.0, "radius": 0, "dash": False, "hidden": False, "locked": False,
            "gid": None, "name": "", "size": 24, "text": "", "width": 0,
            "fill": None, "stroke": None}


def prop(s, key):
    return s.get(key, DEFAULTS.get(key))


def type_label(typ):
    return tr("type_" + typ)


def display_name(s):
    if s.get("name"):
        return s["name"]
    label = type_label(s["type"])
    if s["type"] == "text":
        t = s.get("text", "")
        label += f' "{t[:14]}{"…" if len(t) > 14 else ""}"'
    return label


# ── creation ────────────────────────────────────────────────────────────────
def make_shape(typ, pts, style):
    """Create a new (id-less) shape using the current style dict."""
    s = {"id": 0, "type": typ, "pts": list(pts), "fill": style["fill"],
         "stroke": style["stroke"], "width": style["width"]}
    if typ in STROKE_ONLY:
        s["fill"] = None
        s["stroke"] = style["stroke"] or style["fill"] or "#000000"
        s["width"] = max(1, style["width"])
    if typ == "text":
        s["fill"] = style["fill"] or style["stroke"] or "#000000"
        s["stroke"] = None
        s["width"] = 0
        s["size"] = style["font_size"]
        s["text"] = ""
    else:
        if style.get("dash"):
            s["dash"] = True
    if typ == "rect" and style.get("radius"):
        s["radius"] = style["radius"]
    return s


# ── geometry queries ────────────────────────────────────────────────────────
def box_center(s):
    p = s["pts"]
    return (p[0] + p[2]) / 2, (p[1] + p[3]) / 2


def renders_as_polygon(s):
    """rect/ellipse that Tk cannot draw natively (rotated, or rounded corners)."""
    if s["type"] == "rect":
        return bool(prop(s, "rot")) or prop(s, "radius") > 0
    if s["type"] == "ellipse":
        return bool(prop(s, "rot"))
    return False


def outline(s):
    """World-space outline polygon for rect/ellipse; the points for point types."""
    t = s["type"]
    if t in POINT_TYPES:
        return list(s["pts"])
    if t not in BOX_TYPES:
        return None
    x0, y0, x1, y1 = s["pts"]
    if t == "rect":
        pts = g.rounded_rect_points(x0, y0, x1, y1, prop(s, "radius"))
    else:
        pts = g.ellipse_points(x0, y0, x1, y1)
    rot = prop(s, "rot")
    if rot:
        cx, cy = box_center(s)
        pts = g.rotate_pts(pts, cx, cy, rot)
    return pts


def corner_points(s):
    """Four (rotated) corners of a rect/ellipse box."""
    x0, y0, x1, y1 = s["pts"]
    pts = [x0, y0, x1, y0, x1, y1, x0, y1]
    rot = prop(s, "rot")
    if rot:
        cx, cy = box_center(s)
        pts = g.rotate_pts(pts, cx, cy, rot)
    return pts


def text_fallback_bbox(s):
    x, y = s["pts"]
    size = prop(s, "size")
    return (x, y, x + size, y + size)


def geometry_bbox(s):
    """Axis-aligned bbox for non-text shapes (text needs the canvas to measure)."""
    if s["type"] == "text":
        return text_fallback_bbox(s)
    if s["type"] in BOX_TYPES and prop(s, "rot"):
        return g.points_bbox(corner_points(s) if s["type"] == "rect" else outline(s))
    return g.points_bbox(s["pts"])


def anchors(s):
    """Editable anchor points for the Direct Selection tool, as [(x, y), ...]."""
    if s["type"] in POINT_TYPES:
        p = s["pts"]
        return [(p[i], p[i + 1]) for i in range(0, len(p), 2)]
    if s["type"] == "rect":
        p = corner_points(s)
        return [(p[i], p[i + 1]) for i in range(0, len(p), 2)]
    return []


def to_path(s):
    """Convert a rect to an editable polygon (corners only)."""
    n = copy.deepcopy(s)
    if s["type"] == "rect":
        n["type"] = "polygon"
        n["pts"] = corner_points(s)
        n.pop("radius", None)
    return n


def replace_in_place(s, new):
    """Swap the contents of shape dict ``s`` for ``new`` (keeps object identity)."""
    s.clear()
    s.update(new)


# ── transforms (all return a new dict) ──────────────────────────────────────
def translate(s, dx, dy):
    """In place."""
    s["pts"] = g.translate_pts(s["pts"], dx, dy)


def rotated(s, deg, cx, cy):
    n = copy.deepcopy(s)
    t = s["type"]
    if t in POINT_TYPES or t == "text":
        n["pts"] = g.rotate_pts(s["pts"], cx, cy, deg)
    else:
        bx, by = box_center(s)
        ncx, ncy = g.rotate_point(bx, by, cx, cy, deg)
        x0, y0, x1, y1 = s["pts"]
        hw, hh = abs(x1 - x0) / 2, abs(y1 - y0) / 2
        n["pts"] = [ncx - hw, ncy - hh, ncx + hw, ncy + hh]
    n["rot"] = round(g.normalize_angle(prop(s, "rot") + deg), 4)
    if not n["rot"]:
        n.pop("rot", None)
    return n


def scaled(s, bbox, new_bbox):
    """Scale ``s`` from the selection box ``bbox`` into ``new_bbox``."""
    n = copy.deepcopy(s)
    n["pts"] = g.scale_pts(s["pts"], bbox, new_bbox)
    kx, ky = g.scale_factors(bbox, new_bbox)
    k = math.sqrt(abs(kx * ky))
    if s["type"] == "text":
        n["size"] = max(1, int(round(prop(s, "size") * k)))
    if prop(s, "radius"):
        n["radius"] = max(0, round(prop(s, "radius") * k, 2))
    return n


def flipped(s, axis, c, bbox):
    """Mirror across the vertical (axis='h') or horizontal (axis='v') line at ``c``.

    ``bbox`` is the shape's own bbox (needed to keep text reading left-to-right).
    """
    n = copy.deepcopy(s)
    p = s["pts"]
    idx = 0 if axis == "h" else 1
    if s["type"] == "text":
        x, y = p
        if axis == "h":
            n["pts"] = [2 * c - bbox[2] + (x - bbox[0]), y]
        else:
            n["pts"] = [x, 2 * c - bbox[3] + (y - bbox[1])]
    else:
        n["pts"] = [(2 * c - v) if i % 2 == idx else v for i, v in enumerate(p)]
    if prop(s, "rot"):
        n["rot"] = -prop(s, "rot")
    return n
