"""The drawing: an ordered list of shapes (index 0 = bottom of the stack)."""

import copy

from vectra.model.shapes import prop


class Document:
    def __init__(self, shapes=None):
        self.shapes = []
        self.next_id = 1
        if shapes:
            self.load(shapes)

    # ── lifecycle ───────────────────────────────────────────────────────────
    def clear(self):
        self.shapes = []
        self.next_id = 1

    def load(self, shapes):
        self.shapes = shapes
        self.next_id = max((s["id"] for s in shapes), default=0) + 1

    def snapshot(self):
        return copy.deepcopy(self.shapes), self.next_id

    def restore(self, snap):
        self.shapes, self.next_id = copy.deepcopy(snap[0]), snap[1]

    # ── queries ─────────────────────────────────────────────────────────────
    def by_id(self, sid):
        for s in self.shapes:
            if s["id"] == sid:
                return s
        return None

    def ids(self):
        return {s["id"] for s in self.shapes}

    def of_ids(self, ids):
        """Shapes whose id is in ``ids``, in stacking order."""
        return [s for s in self.shapes if s["id"] in ids]

    def editable(self):
        """Shapes that can be selected (visible and unlocked)."""
        return [s for s in self.shapes if not prop(s, "hidden") and not prop(s, "locked")]

    def group_members(self, gid):
        return [s for s in self.shapes if gid is not None and s.get("gid") == gid]

    def expand_groups(self, ids):
        """``ids`` plus every other member of any group they belong to."""
        gids = {s.get("gid") for s in self.of_ids(ids)} - {None}
        if not gids:
            return set(ids)
        return set(ids) | {s["id"] for s in self.shapes if s.get("gid") in gids}

    def units(self, ids):
        """Selection split into units that move together: each group is one unit."""
        units, by_gid = [], {}
        for s in self.of_ids(ids):
            gid = s.get("gid")
            if gid is None:
                units.append([s])
            elif gid in by_gid:
                by_gid[gid].append(s)
            else:
                by_gid[gid] = [s]
                units.append(by_gid[gid])
        return units

    def new_gid(self):
        return max((s.get("gid") or 0 for s in self.shapes), default=0) + 1

    # ── mutations ───────────────────────────────────────────────────────────
    def add(self, shape):
        s = copy.deepcopy(shape)
        s["id"] = self.next_id
        self.next_id += 1
        self.shapes.append(s)
        return s

    def insert_copies(self, items, offset):
        """Append deep copies shifted by ``offset``; groups get fresh group ids."""
        gid_map, new_ids = {}, set()
        next_gid = self.new_gid()
        for s in items:
            n = copy.deepcopy(s)
            n["id"] = self.next_id
            self.next_id += 1
            n["pts"] = [v + offset for v in n["pts"]]
            if n.get("gid") is not None:
                if n["gid"] not in gid_map:
                    gid_map[n["gid"]] = next_gid
                    next_gid += 1
                n["gid"] = gid_map[n["gid"]]
            n.pop("locked", None)
            n.pop("hidden", None)
            self.shapes.append(n)
            new_ids.add(n["id"])
        return new_ids

    def remove(self, ids):
        self.shapes = [s for s in self.shapes if s["id"] not in ids]

    def replace(self, shape):
        for i, s in enumerate(self.shapes):
            if s["id"] == shape["id"]:
                self.shapes[i] = shape
                return

    # ── stacking order ──────────────────────────────────────────────────────
    def bring_front(self, ids):
        self.shapes = [s for s in self.shapes if s["id"] not in ids] + self.of_ids(ids)

    def send_back(self, ids):
        self.shapes = self.of_ids(ids) + [s for s in self.shapes if s["id"] not in ids]

    def bring_forward(self, ids):
        sh = self.shapes
        for i in range(len(sh) - 2, -1, -1):
            if sh[i]["id"] in ids and sh[i + 1]["id"] not in ids:
                sh[i], sh[i + 1] = sh[i + 1], sh[i]

    def send_backward(self, ids):
        sh = self.shapes
        for i in range(1, len(sh)):
            if sh[i]["id"] in ids and sh[i - 1]["id"] not in ids:
                sh[i], sh[i - 1] = sh[i - 1], sh[i]

    # ── groups ──────────────────────────────────────────────────────────────
    def group(self, ids):
        """Group shapes; members become contiguous at the topmost member's level."""
        members = self.of_ids(ids)
        if len(members) < 2:
            return None
        gid = self.new_gid()
        for s in members:
            s["gid"] = gid
        top_index = max(i for i, s in enumerate(self.shapes) if s["id"] in ids)
        before = [s for s in self.shapes[:top_index + 1] if s["id"] not in ids]
        after = [s for s in self.shapes[top_index + 1:] if s["id"] not in ids]
        self.shapes = before + members + after
        return gid

    def ungroup(self, ids):
        changed = False
        for s in self.of_ids(ids):
            if s.pop("gid", None) is not None:
                changed = True
        return changed
