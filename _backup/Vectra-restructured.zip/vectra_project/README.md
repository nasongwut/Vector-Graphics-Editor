# Vectra — Vector Graphics Editor

โปรแกรมวาดภาพเวกเตอร์ด้วย Python + Tkinter (ไม่ต้องติดตั้งอะไรเพิ่ม) · รองรับ 2 ภาษา ไทย / English

```bash
python main.py          # หรือ  python -m vectra
python -m unittest discover tests     # รันเทสต์ (ไม่ต้องเปิดหน้าต่าง)
```

ต้องใช้ Python 3.8+ ที่มี Tk 8.6 (macOS: ติดตั้ง Python จาก python.org หรือ `brew install python-tk`)

## โครงสร้างโค้ด

```
main.py                    จุดเริ่มโปรแกรม
vectra/
  app.py                   main(): ตั้งภาษา แล้วเปิดหน้าต่าง
  config.py                ค่าคงที่ (artboard, grid, undo, modifier keys)
  i18n.py                  ข้อความ UI ทั้งหมด ไทย/อังกฤษ + tr()
  settings.py              เก็บค่าที่ผู้ใช้เลือก (~/.vectra/settings.json)
  model/                   ── ไม่ใช้ Tkinter, เทสต์ได้ ──
    geometry.py            คณิตศาสตร์: bbox, หมุน, ย่อขยาย, ดาว, มุมมน
    shapes.py              รูปทรง (dict) + การแปลง rotate/scale/flip
    document.py            รายการรูปทรง, ลำดับชั้น, กลุ่ม
    history.py             Undo / Redo
  fileio/
    json_io.py             บันทึก/เปิด .json (อ่านไฟล์เวอร์ชันเก่าได้)
    svg_export.py          ส่งออก .svg
  ui/
    editor.py              VectorEditor: state + ประกอบ UI
    interaction.py         เมาส์ / เครื่องมือ
    commands.py            คำสั่งแก้ไข จัดเรียง จัดแนว กลุ่ม ล็อก ซ่อน
    style.py               สี เส้น ขนาด ↔ แผงคุณสมบัติ
    files.py               ใหม่ / เปิด / บันทึก / ส่งออก
    renderer.py            วาดลง Canvas
    viewport.py            ซูม / เลื่อนมุมมอง
    layout.py              แถบบน แถบเครื่องมือ แถบสถานะ เมนูคลิกขวา
    shortcuts.py           คีย์ลัด
    tools.py theme.py widgets.py
    panels/                แผงขวา: คุณสมบัติ · จัดวาง · เลเยอร์
tests/test_model.py
```

เพิ่มข้อความใหม่: ใส่ใน `vectra/i18n.py` เป็น `"key": ("ไทย", "English")` แล้วเรียก `tr("key")`

## เครื่องมือและคีย์ลัด

| คีย์ | เครื่องมือ | คีย์ | เครื่องมือ |
|---|---|---|---|
| V | เลือก / ย้าย / ย่อขยาย / หมุน | R | สี่เหลี่ยม (มุมมนได้) |
| A | Direct Selection (แก้จุด) | E | วงรี |
| H | มือ (เลื่อนมุมมอง) | L | เส้นตรง |
| Z | ซูม (Alt = ซูมออก) | G | รูปหลายเหลี่ยม |
| I | Eyedropper | S | รูปดาว (↑/↓ ระหว่างลาก = จำนวนแฉก) |
| P | ปากกาวาดอิสระ | T | ข้อความ |

| คีย์ลัด | คำสั่ง |
|---|---|
| Ctrl+Z / Ctrl+Y | ย้อน / ทำซ้ำ |
| Ctrl+C / V / D | คัดลอก / วาง / ทำสำเนา |
| Ctrl+G / Ctrl+Shift+G | จัดกลุ่ม / แยกกลุ่ม |
| Ctrl+2 / Ctrl+Alt+2 | ล็อก / ปลดล็อกทั้งหมด |
| Ctrl+3 / Ctrl+Alt+3 | ซ่อน / แสดงทั้งหมด |
| Shift+X / D | สลับสีพื้น-เส้น / สีเริ่มต้น |
| ] [ (Shift = สุด) | เลื่อนลำดับชั้น |
| ลูกศร (Shift = 10) | ขยับ |
| Shift ขณะหมุน | ล็อกทีละ 15° |
| Ctrl+S / O / N / E | บันทึก / เปิด / ใหม่ / ส่งออก SVG |
| Ctrl+0 / Ctrl+1 | พอดีจอ / 100% |
| Ctrl+' / Ctrl+; | กริด / Snap |
